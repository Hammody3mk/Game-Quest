export const generateFallbackQuestions = (count: number, rank?: string) => {
  const isCasualFusion = count === 30;
  
  if (isCasualFusion) {
    // 10 Easy, 10 Medium, 10 Hard
    return [
      // EASY (10)
      { question: "What is the capital of France?", options: ["London", "Paris", "Berlin", "Rome"], correctAnswerIndex: 1 },
      { question: "What is 5 + 5?", options: ["8", "9", "10", "11"], correctAnswerIndex: 2 },
      { question: "Which planet is known as the Red Planet?", options: ["Earth", "Mars", "Jupiter", "Venus"], correctAnswerIndex: 1 },
      { question: "What is the largest mammal?", options: ["Elephant", "Blue Whale", "Giraffe", "Shark"], correctAnswerIndex: 1 },
      { question: "Who painted the Mona Lisa?", options: ["Van Gogh", "Picasso", "Da Vinci", "Rembrandt"], correctAnswerIndex: 2 },
      { question: "What is water's chemical formula?", options: ["H2O", "CO2", "O2", "NaCl"], correctAnswerIndex: 0 },
      { question: "How many continents are there?", options: ["5", "6", "7", "8"], correctAnswerIndex: 2 },
      { question: "What color is a banana?", options: ["Red", "Blue", "Yellow", "Green"], correctAnswerIndex: 2 },
      { question: "Which animal says 'Meow'?", options: ["Dog", "Cat", "Cow", "Pig"], correctAnswerIndex: 1 },
      { question: "What is the opposite of hot?", options: ["Warm", "Spicy", "Cold", "Boiling"], correctAnswerIndex: 2 },
      
      // MEDIUM (10)
      { question: "What year did the Titanic sink?", options: ["1912", "1905", "1898", "1923"], correctAnswerIndex: 0 },
      { question: "What is the hardest natural substance?", options: ["Gold", "Iron", "Diamond", "Platinum"], correctAnswerIndex: 2 },
      { question: "Who wrote 'Romeo and Juliet'?", options: ["Charles Dickens", "William Shakespeare", "Mark Twain", "Jane Austen"], correctAnswerIndex: 1 },
      { question: "What is the capital of Japan?", options: ["Kyoto", "Osaka", "Tokyo", "Seoul"], correctAnswerIndex: 2 },
      { question: "Which element has the symbol 'O'?", options: ["Gold", "Oxygen", "Osmium", "Phosphorus"], correctAnswerIndex: 1 },
      { question: "How many bones are in the adult human body?", options: ["206", "208", "210", "200"], correctAnswerIndex: 0 },
      { question: "What is the longest river in the world?", options: ["Amazon", "Nile", "Yangtze", "Mississippi"], correctAnswerIndex: 1 },
      { question: "Which planet is closest to the Sun?", options: ["Venus", "Earth", "Mercury", "Mars"], correctAnswerIndex: 2 },
      { question: "Who was the first President of the USA?", options: ["Abraham Lincoln", "Thomas Jefferson", "George Washington", "John Adams"], correctAnswerIndex: 2 },
      { question: "What is the square root of 144?", options: ["10", "12", "14", "16"], correctAnswerIndex: 1 },
      
      // HARD (10)
      { question: "What is the rarest blood type?", options: ["O-", "B-", "AB-", "A-"], correctAnswerIndex: 2 },
      { question: "Which country has the most islands?", options: ["Indonesia", "Philippines", "Sweden", "Canada"], correctAnswerIndex: 2 },
      { question: "Who discovered penicillin?", options: ["Marie Curie", "Alexander Fleming", "Louis Pasteur", "Isaac Newton"], correctAnswerIndex: 1 },
      { question: "What is the smallest country in the world?", options: ["Monaco", "Nauru", "Vatican City", "Tuvalu"], correctAnswerIndex: 2 },
      { question: "Which gas is most abundant in the Earth's atmosphere?", options: ["Oxygen", "Carbon Dioxide", "Nitrogen", "Hydrogen"], correctAnswerIndex: 2 },
      { question: "In what year was the first computer mouse invented?", options: ["1964", "1973", "1981", "1958"], correctAnswerIndex: 0 },
      { question: "What is the heaviest naturally occurring element?", options: ["Plutonium", "Uranium", "Osmium", "Lead"], correctAnswerIndex: 1 },
      { question: "Who was the first woman to win a Nobel Prize?", options: ["Mother Teresa", "Rosa Parks", "Marie Curie", "Amelia Earhart"], correctAnswerIndex: 2 },
      { question: "What is the capital of Mongolia?", options: ["Ulaanbaatar", "Astana", "Tashkent", "Bishkek"], correctAnswerIndex: 0 },
      { question: "Which philosopher said 'I think, therefore I am'?", options: ["Socrates", "Plato", "Aristotle", "René Descartes"], correctAnswerIndex: 3 }
    ];
  }

  // EXTREME/RANKED (10 Questions)
  return [
    { question: `[${rank} Rank] In particle physics, what theoretical particle is postulated to mediate gravity?`, options: ["Boson", "Tachyon", "Graviton", "Fermion"], correctAnswerIndex: 2 },
    { question: `[${rank} Rank] Which ancient civilization built the city of Teotihuacan?`, options: ["Aztec", "Maya", "Olmec", "Unknown/Mesoamerican"], correctAnswerIndex: 3 },
    { question: `[${rank} Rank] What is the mathematical term for a surface with only one side and one boundary?`, options: ["Klein Bottle", "Möbius Strip", "Torus", "Hypercube"], correctAnswerIndex: 1 },
    { question: `[${rank} Rank] Which enzyme is responsible for unzipping DNA during replication?`, options: ["Ligase", "Polymerase", "Helicase", "Primase"], correctAnswerIndex: 2 },
    { question: `[${rank} Rank] In computer science, what is the time complexity of a binary search?`, options: ["O(n)", "O(n log n)", "O(log n)", "O(1)"], correctAnswerIndex: 2 },
    { question: `[${rank} Rank] What is the precise speed of light in a vacuum (m/s)?`, options: ["299,792,458", "300,000,000", "299,792,000", "299,000,000"], correctAnswerIndex: 0 },
    { question: `[${rank} Rank] Who formulated the incompleteness theorems in mathematical logic?`, options: ["Alan Turing", "John von Neumann", "Kurt Gödel", "Bertrand Russell"], correctAnswerIndex: 2 },
    { question: `[${rank} Rank] Which of these is NOT a noble gas?`, options: ["Krypton", "Xenon", "Radon", "Halogen"], correctAnswerIndex: 3 },
    { question: `[${rank} Rank] In astrophysics, what is the event horizon of a black hole?`, options: ["The singularity", "The point of no return", "The accretion disk", "The photon sphere"], correctAnswerIndex: 1 },
    { question: `[${rank} Rank] The 'Voynich manuscript' is an illustrated codex hand-written in an unknown writing system. Carbon dating puts it in which century?`, options: ["13th", "14th", "15th", "16th"], correctAnswerIndex: 2 }
  ];
};
