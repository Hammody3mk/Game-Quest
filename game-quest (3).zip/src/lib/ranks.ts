export const RANKS = [
  { name: 'Bronze', min: 0 },
  { name: 'Silver', min: 250 },
  { name: 'Gold', min: 1000 },
  { name: 'Platinum', min: 2500 },
  { name: 'Diamond', min: 5000 }
];

export const getRankInfo = (points: number) => {
  let currentRank = RANKS[0];
  let nextRank = null;
  for (let i = 0; i < RANKS.length; i++) {
    if (points >= RANKS[i].min) {
      currentRank = RANKS[i];
      nextRank = RANKS[i+1] || null;
    } else {
      break;
    }
  }
  return { currentRank, nextRank };
};

export const getDisplayRank = (userProfile: any) => {
  if (!userProfile) return 'Beginner';
  if (userProfile.hiddenRank) return userProfile.hiddenRank;
  // If points are beyond Diamond (5000), they still show as Diamond unless admin sets a hidden rank
  return getRankInfo(userProfile.quizPoints || 0).currentRank.name;
};
