import { GoogleGenAI, Type } from '@google/genai';
import { generateFallbackQuestions } from './fallbackQuestions';

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export async function generateQuizQuestions(difficulty: string, count: number, rank?: string) {
  try {
    const isHighRank = rank && ['Gold', 'Platinum', 'Diamond'].includes(rank);
    const isCasualFusion = count === 30;

    let difficultyPrompt = `The difficulty should be ${difficulty}.`;
    if (isCasualFusion) {
      difficultyPrompt = `This is a "Fusion" mode. You MUST generate exactly 30 questions: 10 EASY, 10 MEDIUM, and 10 HARD.`;
    } else if (isHighRank) {
      difficultyPrompt = `The player is ${rank} rank (Elite/Legendary). Generate 10 EXTREMELY HARD, obscure questions. No common knowledge.`;
    }

    const response = await ai.models.generateContent({
      model: 'gemini-1.5-flash',
      contents: `You are the ultimate Quiz Master. 
      ${difficultyPrompt}
      
      Requirements:
      - Categories: Diverse mix (History, Quantum Physics, Deep Lore, Science, Tech, Geography).
      - Output: Valid JSON array of objects.
      - Each object: "question" (string), "options" (array of 4 strings), "correctAnswerIndex" (integer 0-3).
      
      DO NOT return anything but the JSON array. Do not say "Here are your questions".`,
      config: {
        responseMimeType: 'application/json',
        maxOutputTokens: 8192,
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              correctAnswerIndex: { type: Type.INTEGER },
            },
            required: ['question', 'options', 'correctAnswerIndex'],
          },
        },
      },
    });

    const text = response.text;
    if (text) {
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      const cleaned = jsonMatch ? jsonMatch[0] : text.trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
    return [];
  } catch (error) {
    console.error('Error generating questions (falling back to offline list):', error);
    return generateFallbackQuestions(count, rank);
  }
}

export async function generateMultiplayerQuestions(subject: string, amount: number = 10) {
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-1.5-flash',
      contents: `You are a multiplayer Quiz Master. Generate exactly ${amount} questions about the subject: ${subject}. 
      We do not know if they are hard, easy, or medium. Make sure they are random difficulty.
      Requirements:
      - Output: Valid JSON array of objects.
      - Each object: "question" (string), "options" (array of 4 strings), "correctAnswerIndex" (integer 0-3).
      DO NOT return anything but the JSON array.`,
      config: {
        responseMimeType: 'application/json',
        maxOutputTokens: 8192,
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              correctAnswerIndex: { type: Type.INTEGER },
            },
            required: ['question', 'options', 'correctAnswerIndex'],
          },
        },
      },
    });

    const text = response.text;
    if (text) {
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      const cleaned = jsonMatch ? jsonMatch[0] : text.trim();
      const parsed = JSON.parse(cleaned);
      if (Array.isArray(parsed) && parsed.length > 0) return parsed;
    }
    throw new Error('No array returned or empty array');
  } catch (error) {
    console.error('Error generating multiplayer questions:', error);
    // Simple fallback math questions if failed
    const fallbacks = [];
    for(let i=0; i<amount; i++) {
        const a = Math.floor(Math.random() * 20)+1;
        const b = Math.floor(Math.random() * 20)+1;
        fallbacks.push({ question: `What is ${a} + ${b}?`, options: [`${a+b+1}`, `${a+b}`, `${a+b-1}`, `${a+b+2}`], correctAnswerIndex: 1 });
    }
    return fallbacks;
  }
}

export async function judgeChallengeProof(description: string, mediaBase64: string, mimeType: string) {
  try {
    const isVideo = mimeType.startsWith('video/');
    const response = await ai.models.generateContent({
      model: 'gemini-1.5-flash',
      contents: [
        `You are a strict judge for a real-world challenge game. 
         The user claimed to complete this challenge: "${description}". 
         Check the ${isVideo ? 'video' : 'photo'} proof provided. 
         Is there clear evidence in the media to confidently verify the challenge was completed? 
         Be fair but firm. Reply with a JSON object containing "approved" (boolean) and "reason" (string).`,
        { inlineData: { data: mediaBase64.split(',')[1] || mediaBase64, mimeType } },
      ],
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            approved: { type: Type.BOOLEAN },
            reason: { type: Type.STRING },
          },
          required: ['approved', 'reason'],
        },
      },
    });

    const text = response.text;
    if (text) {
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      const cleaned = jsonMatch ? jsonMatch[0] : text.trim();
      return JSON.parse(cleaned);
    }
  } catch (error) {
    console.error('Error judging challenge:', error);
  }
  return { approved: false, reason: 'The AI could not process the proof. Please try again with a clearer photo or shorter video.' };
}
