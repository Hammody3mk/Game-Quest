import React, { createContext, useContext, useEffect, useState } from 'react';
import { User as FirebaseUser, onAuthStateChanged, signOut } from 'firebase/auth';
import { collection, doc, getDoc, onSnapshot, query, setDoc } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';

interface UserProfile {
  username: string;
  quizPoints: number;
  challengePoints: number;
  rank: string;
  hiddenRank?: string;
  isBanned?: boolean;
  banUntil?: number;
  banReason?: string;
  depth?: number;
  avatar?: string;
  friends?: string[];
  inventory?: string[];
}

interface AuthContextType {
  currentUser: FirebaseUser | null;
  userProfile: UserProfile | null;
  isAdmin: boolean;
  loading: boolean;
  activeEvents: any[];
  logout: () => Promise<void>;
  reloadProfile: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({} as AuthContextType);

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [userProfile, setUserProfile] = useState<UserProfile | null>(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [activeEvents, setActiveEvents] = useState<any[]>([]);

  useEffect(() => {
    const q = query(collection(db, 'events'));
    const unsub = onSnapshot(q, (snapshot) => {
      const evts: any[] = [];
      const now = Date.now();
      snapshot.forEach(doc => {
        const data = doc.data();
        if (data.startedAt && data.durationMins != null) {
          const startMs = data.startedAt.toMillis();
          const endMs = startMs + (data.durationMins * 60000);
          if (now < endMs || data.durationMins === 0) {
            evts.push({ id: doc.id, ...data });
          }
        }
      });
      setActiveEvents(evts);
    }, (error) => {
      handleFirestoreError(error, OperationType.LIST, 'events');
    });
    return unsub;
  }, []);

  useEffect(() => {
    let unsubProfile: (() => void) | null = null;

    const fetchAdminStatus = async (user: FirebaseUser) => {
      try {
        if (user.email === 'almoaibed@gmail.com') {
          setIsAdmin(true);
        } else {
          const adminDoc = await getDoc(doc(db, 'admins', user.uid));
          setIsAdmin(adminDoc.exists());
        }
      } catch (error) {
        console.error("Error fetching admin status:", error);
      }
    };

    const unsubscribeAuth = onAuthStateChanged(auth, async (user) => {
      setCurrentUser(user);
      if (user) {
        await fetchAdminStatus(user);
        
        // Listen to profile updates live
        const userRef = doc(db, 'users', user.uid);
        unsubProfile = onSnapshot(userRef, async (userDoc) => {
          if (userDoc.exists()) {
            const data = userDoc.data() as UserProfile;
            
            // Notification Logic
            if ('Notification' in window && Notification.permission === 'granted') {
               setUserProfile((prevProfile) => {
                  if (prevProfile) {
                     const prevTotal = (prevProfile.quizPoints || 0) + (prevProfile.challengePoints || 0);
                     const newTotal = (data.quizPoints || 0) + (data.challengePoints || 0);
                     if (newTotal > prevTotal && localStorage.getItem('gq_notif_admin') !== 'false') {
                        // Rough heuristic: if it goes up randomly, say it's a gift or reward
                        new Notification("Points Earned!", { body: `Your points increased by ${newTotal - prevTotal}!` });
                     }
                     if ((data.depth !== prevProfile.depth) && localStorage.getItem('gq_notif_depth') !== 'false') {
                        new Notification("Depth Alert", { body: `Your depth has changed to ${data.depth}. Time to pay your dues!` });
                     }
                  }
                  return data;
               });
            } else {
               setUserProfile(data);
            }

            if (data.isBanned && data.banUntil && data.banUntil > Date.now()) {
              const endDate = new Date(data.banUntil).toLocaleString();
              alert(`Sorry, the owner of the game banned you.\nReason: ${data.banReason || 'No reason provided'}\nEnds: ${endDate}`);
              await signOut(auth);
              return;
            }
            setUserProfile(data);
          } else {
            setUserProfile(null);
          }
        }, (error) => {
          handleFirestoreError(error, OperationType.GET, 'users');
        });

      } else {
        setUserProfile(null);
        setIsAdmin(false);
        if (unsubProfile) {
          unsubProfile();
          unsubProfile = null;
        }
      }
      setLoading(false);
    });

    return () => {
      unsubscribeAuth();
      if (unsubProfile) unsubProfile();
    };
  }, []);

  const logout = async () => {
    await signOut(auth);
  };

  const reloadProfile = async () => {
    // Left for compatibility, but profile is now auto-updating
  };

  return (
    <AuthContext.Provider value={{ currentUser, userProfile, isAdmin, loading, activeEvents, logout, reloadProfile }}>
      {!loading && children}
    </AuthContext.Provider>
  );
};
