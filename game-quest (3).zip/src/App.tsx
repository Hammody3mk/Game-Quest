/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect } from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { Sidebar } from './components/Sidebar';
import { AdventureCard, ComingSoonCard } from './components/AdventureCard';
import { Brain, Swords, ShoppingBag } from 'lucide-react';
import { useAuth } from './contexts/AuthContext';
import { AuthScreen } from './components/AuthScreen';
import { QuizGame } from './components/QuizGame';
import { ChallengeMe } from './components/ChallengeMe';
import { AdminPanel } from './components/AdminPanel';
import { Multiplayer } from './components/Multiplayer';
import { ItemShop } from './components/ItemShop';
import { Settings } from './components/Settings';
import { Depth } from './components/Depth';
import { ActiveEventsOverlay } from './components/ActiveEventsOverlay';

import { CompleteProfile } from './components/CompleteProfile';

function Dashboard() {
  const { userProfile } = useAuth();
  
  return (
    <div className="w-full max-w-7xl mx-auto p-10">
      <header className="flex justify-between items-center mb-12">
        <div>
          <h1 className="text-4xl font-extrabold mb-2 text-white">Welcome to GameQuest</h1>
          <p className="text-gray-400">Choose your adventure · 💬 {userProfile?.quizPoints || 0} Quiz Points · ⚡ {userProfile?.challengePoints || 0} Challenge Points</p>
        </div>
        <button className="bg-[#181520] border border-[#2a2436] p-3 rounded-full text-gray-400">?</button>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
        <AdventureCard to="/quiz" icon={Brain} title="Quiz Game" desc="Answer questions and climb the ranks" />
        <AdventureCard to="/challenge" icon={Brain} title="Challenge Me" desc="Set personal challenges and earn points" />
        <AdventureCard to="/multiplayer" icon={Swords} title="Multiplayer" desc="Challenge friends and wager points" />
        <AdventureCard to="/shop" icon={ShoppingBag} title="Item Shop" desc="Spend your points on cool items" />
      </section>

      <section>
        <div className="w-1/4">
          <ComingSoonCard />
        </div>
      </section>
    </div>
  );
}

export default function App() {
  const { currentUser, userProfile, loading } = useAuth();

  useEffect(() => {
    const savedTheme = localStorage.getItem('gq_theme');
    if (savedTheme) {
      document.documentElement.setAttribute('data-theme', savedTheme);
    }
  }, []);

  if (loading) {
    return <div className="min-h-screen bg-[#0b090f] flex items-center justify-center text-white">Loading...</div>;
  }

  if (!currentUser) {
    return <AuthScreen />;
  }

  if (!userProfile) {
    return <CompleteProfile />;
  }

  return (
    <div className="flex bg-[#0b090f] min-h-screen text-white font-sans h-screen overflow-hidden">
      <Sidebar />
      <ActiveEventsOverlay />
      <main className="flex-grow overflow-y-auto flex flex-col items-center">
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/quiz" element={<QuizGame />} />
          <Route path="/challenge" element={<ChallengeMe />} />
          <Route path="/multiplayer" element={<Multiplayer />} />
          <Route path="/shop" element={<ItemShop />} />
          <Route path="/depth" element={<Depth />} />
          <Route path="/settings" element={<Settings />} />
          <Route path="/admin" element={<AdminPanel />} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>
    </div>
  );
}
