import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { motion, AnimatePresence } from 'motion/react';
import { Gift, Coins } from 'lucide-react';

export const ActiveEventsOverlay = () => {
  const { activeEvents, userProfile, currentUser, reloadProfile } = useAuth();
  
  // Local state to prevent repeatedly collecting the same entity in short succession
  const [collectedCoin, setCollectedCoin] = useState(false);
  const [openedGift, setOpenedGift] = useState(false);

  const hasCoinRain = activeEvents.some(e => e.id === 'collect_coins');
  const hasMysteryGift = activeEvents.some(e => e.id === 'mystery_gift');

  useEffect(() => {
    if (!hasCoinRain) setCollectedCoin(false);
    if (!hasMysteryGift) setOpenedGift(false);
  }, [hasCoinRain, hasMysteryGift]);

  const collectCoin = async () => {
    if (!currentUser || !userProfile || collectedCoin) return;
    setCollectedCoin(true);
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), {
        quizPoints: userProfile.quizPoints + 50,
        updatedAt: serverTimestamp()
      });
      await reloadProfile();
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  const openGift = async () => {
    if (!currentUser || !userProfile || openedGift) return;
    setOpenedGift(true);
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), {
        challengePoints: userProfile.challengePoints + 150,
        updatedAt: serverTimestamp()
      });
      await reloadProfile();
      alert("Mystery Gift opened! You got 150 Challenge Points!");
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  if (!currentUser) return null;

  return (
    <div className="fixed inset-0 pointer-events-none z-50 overflow-hidden">
      <AnimatePresence>
        {hasCoinRain && !collectedCoin && (
          <motion.div
            initial={{ y: -100, x: Math.random() * window.innerWidth }}
            animate={{ y: window.innerHeight + 100, rotate: 360 }}
            transition={{ duration: 10, repeat: Infinity, ease: 'linear' }}
            className="absolute cursor-pointer pointer-events-auto"
            onClick={collectCoin}
          >
            <div className="bg-amber-400 w-16 h-16 rounded-full border-4 border-amber-600 shadow-[0_0_20px_theme(colors.amber.500)] flex items-center justify-center animate-pulse hover:scale-125 transition-transform">
              <Coins className="text-amber-800 w-8 h-8" />
            </div>
          </motion.div>
        )}

        {hasMysteryGift && !openedGift && (
          <motion.div
            initial={{ scale: 0 }}
            animate={{ scale: 1 }}
            exit={{ scale: 0 }}
            className="absolute top-1/4 left-1/2 -translate-x-1/2 cursor-pointer pointer-events-auto"
            onClick={openGift}
          >
            <div className="bg-purple-600 w-24 h-24 rounded-2xl shadow-[0_0_40px_theme(colors.purple.500)] flex items-center justify-center animate-bounce hover:bg-purple-500 transition-colors border-2 border-purple-400">
              <Gift className="text-white w-12 h-12" />
            </div>
            <div className="text-center font-bold text-white mt-4 drop-shadow-md bg-black/50 px-3 py-1 rounded-full">Tap to Open!</div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
