import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { judgeChallengeProof } from '../lib/gemini';
import { doc, setDoc, updateDoc, serverTimestamp, collection, query, where, orderBy, limit, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Swords, Camera, CheckCircle, XCircle, Play, AlertCircle, RefreshCw, Trash2, Video } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export const ChallengeMe = () => {
  const { userProfile, currentUser, reloadProfile, activeEvents } = useAuth();
  const [description, setDescription] = useState('');
  const [minutes, setMinutes] = useState(15);
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [challengeId, setChallengeId] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [judgement, setJudgement] = useState<{ approved: boolean, reason: string } | null>(null);
  const [failedProof, setFailedProof] = useState<{ reason: string } | null>(null);
  const [history, setHistory] = useState<any[]>([]);
  const [historyTab, setHistoryTab] = useState(false);
  
  const timerRef = useRef<NodeJS.Timeout | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (currentUser) {
      fetchHistory();
    }
  }, [currentUser, judgement, challengeId]);

  const fetchHistory = async () => {
    if (!currentUser) return;
    try {
      const q = query(
        collection(db, 'challenges'),
        where('userId', '==', currentUser.uid),
        orderBy('createdAt', 'desc'),
        limit(20)
      );
      const snap = await getDocs(q);
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setHistory(data);
    } catch (error) {
      console.error("Error fetching challenge history:", error);
    }
  };

  // Calculate generic multiplier based on active events
  const hasDouble = activeEvents.some(e => e.id === 'double_coins');
  const hasStorm = activeEvents.some(e => e.id === 'xp_storm');
  let multiplier = 1;
  if (hasDouble) multiplier *= 2;
  if (hasStorm) multiplier *= 3;

  useEffect(() => {
    if (timeLeft !== null && timeLeft > 0 && !failedProof) {
      timerRef.current = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
    } else if (timeLeft === 0 && !judgement && !failedProof) {
      // Time is up
      setTimeLeft(null);
      handleGiveUp("Time ran out!");
    }
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
    };
  }, [timeLeft, judgement, failedProof]);

  const handleGiveUp = async (reason?: string) => {
    setLoading(true);
    if (userProfile && currentUser) {
      // Penalty: -100 points
      const deduction = 100;
      let newChallengePoints = userProfile.challengePoints - deduction;
      
      try {
        await updateDoc(doc(db, 'users', currentUser.uid), {
          challengePoints: newChallengePoints,
          updatedAt: serverTimestamp(),
        });
        
        if (challengeId) {
          await updateDoc(doc(db, 'challenges', challengeId), {
            status: 'failed',
            reason: reason || 'User gave up',
            updatedAt: serverTimestamp()
          });
        }
        
        await reloadProfile();
        setJudgement({ approved: false, reason: `You gave up. -100 points. ${reason ? `(${reason})` : ''}` });
        setFailedProof(null);
      } catch (err) {
        console.error(err);
      }
    }
    setLoading(false);
  };

  const startChallenge = async () => {
    if (!description.trim() || !currentUser) return;
    setLoading(true);
    try {
      const id = Date.now().toString();
      await setDoc(doc(db, 'challenges', id), {
        userId: currentUser.uid,
        description,
        timeLimitMins: minutes,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      setChallengeId(id);
      setTimeLeft(minutes * 60);
      setJudgement(null);
      setFailedProof(null);
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'challenges');
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !currentUser || !challengeId) return;

    // Check file size (limit to 20MB for videos)
    if (file.size > 20 * 1024 * 1024) {
      alert("File too large. Please use a smaller photo or a shorter video (max 20MB).");
      return;
    }

    setLoading(true);
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const base64 = event.target?.result as string;
        const result = await judgeChallengeProof(description, base64, file.type);
        
        if (result.approved) {
          const pointsAwarded = 100 * multiplier;
          await updateDoc(doc(db, 'challenges', challengeId), {
            status: 'completed',
            pointsAwarded,
            updatedAt: serverTimestamp()
          });

          await updateDoc(doc(db, 'users', currentUser.uid), {
            challengePoints: userProfile.challengePoints + pointsAwarded,
            updatedAt: serverTimestamp(),
          });
          
          await reloadProfile();
          setJudgement({ approved: true, reason: `Good job! Here's 100 points! AI verified: ${result.reason}` });
          setFailedProof(null);
        } else {
          setFailedProof({ reason: result.reason });
        }
      } catch (error) {
        console.error(error);
        setFailedProof({ reason: "The AI was overwhelmed by your epicness. Try again?" });
      } finally {
        setLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s < 10 ? '0' : ''}${s}`;
  };

  if (judgement) {
    return (
      <div className="p-10 flex flex-col items-center justify-center h-full text-white w-full animate-in fade-in zoom-in duration-500">
        {judgement.approved ? (
          <CheckCircle className="w-24 h-24 text-green-500 mb-6 drop-shadow-[0_0_15px_rgba(34,197,94,0.5)]" />
        ) : (
          <XCircle className="w-24 h-24 text-red-500 mb-6 drop-shadow-[0_0_15px_rgba(239,68,68,0.5)]" />
        )}
        <h2 className="text-4xl font-black mb-4 tracking-tight">
          {judgement.approved ? 'MISSION SUCCESS!' : 'CHALLENGE TERMINATED'}
        </h2>
        <p className="text-xl text-gray-300 text-center max-w-lg mb-8 bg-[#181520] p-6 rounded-2xl border border-[#2a2436] shadow-xl">
          {judgement.reason}
        </p>
        
        {judgement.approved && (
          <div className="bg-green-500/10 border border-green-500/20 px-6 py-3 rounded-full mb-8 animate-bounce">
            <p className="text-green-400 font-black text-2xl">+{100 * multiplier} POINTS!</p>
          </div>
        )}

        <button 
          onClick={() => { setJudgement(null); setChallengeId(null); setDescription(''); }}
          id="new-challenge-btn"
          className="bg-purple-600 hover:bg-purple-700 text-white px-10 py-4 rounded-xl font-black transition-all hover:scale-105 active:scale-95 shadow-lg shadow-purple-600/20"
        >
          START NEW QUEST
        </button>
      </div>
    );
  }

  return (
    <div className="p-10 flex flex-col items-center h-full max-w-3xl mx-auto w-full text-white">
      <div className="bg-amber-600/20 p-4 rounded-full mb-6">
        <Swords className="w-12 h-12 text-amber-500" />
      </div>
      
      <h2 className="text-4xl font-black mb-2 tracking-tight">Challenge Me</h2>
      <p className="text-gray-400 mb-6 text-center text-lg">Set a task, race the clock, and prove it with a photo or video.</p>

      <div className="flex gap-4 mb-8 w-full max-w-sm">
        <button
          onClick={() => setHistoryTab(false)}
          className={`flex-1 py-3 rounded-xl font-bold transition-colors ${!historyTab ? 'bg-amber-600 text-white' : 'bg-[#181520] text-gray-400 hover:text-white'}`}
        >
          New Challenge
        </button>
        <button
          onClick={() => setHistoryTab(true)}
          className={`flex-1 py-3 rounded-xl font-bold transition-colors ${historyTab ? 'bg-amber-600 text-white' : 'bg-[#181520] text-gray-400 hover:text-white'}`}
        >
          History
        </button>
      </div>

      {historyTab ? (
        <div className="w-full bg-[#181520] border border-[#2a2436] rounded-2xl p-6 shadow-2xl">
          <h3 className="text-xl font-bold mb-6 text-white border-b border-[#3b334d] pb-4">Challenge History</h3>
          <div className="space-y-4 max-h-[500px] overflow-y-auto pr-2">
            {history.length > 0 ? history.map((item) => (
              <div key={item.id} className="bg-[#211d2b] border border-[#3b334d] p-4 rounded-xl">
                <div className="flex justify-between items-start mb-2">
                  <div className="font-bold text-lg text-white break-words pr-4">{item.description}</div>
                  <div className={`px-2 py-1 rounded text-xs font-bold uppercase whitespace-nowrap ${item.status === 'completed' ? 'bg-green-600/20 text-green-400' : 'bg-red-600/20 text-red-400'}`}>
                    {item.status}
                  </div>
                </div>
                <div className="text-sm text-gray-400 mb-2">
                  Time info: {item.timeLimitMins} min
                </div>
                {item.reason && (
                  <div className="text-sm text-gray-300 italic bg-[#110e16] p-3 rounded-lg border border-[#2a2436]">
                    "{item.reason}"
                  </div>
                )}
                {item.status === 'completed' && item.pointsAwarded && (
                  <div className="text-green-400 font-bold mt-2">
                    +{item.pointsAwarded} Points
                  </div>
                )}
              </div>
            )) : (
              <div className="text-center py-8 text-gray-500 italic">No challenges yet. Start one today!</div>
            )}
          </div>
        </div>
      ) : timeLeft === null ? (
        <div className="w-full bg-[#181520] border border-[#2a2436] p-8 rounded-2xl shadow-2xl">
          <div className="mb-6">
            <label className="block text-gray-400 text-sm font-black uppercase mb-2 ml-1">I challenge myself to...</label>
            <input
              type="text"
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="e.g. Clean my desk, do 50 squats..."
              className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-4 text-white text-lg focus:outline-none focus:border-amber-500 transition-colors placeholder:text-gray-700"
            />
          </div>
          <div className="mb-8">
            <label className="block text-gray-400 text-sm font-black uppercase mb-2 ml-1">Time Limit (Minutes)</label>
            <input
              type="number"
              min="1"
              max="120"
              value={minutes}
              onChange={(e) => setMinutes(Number(e.target.value))}
              className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-4 text-white text-lg focus:outline-none focus:border-amber-500 transition-colors"
            />
          </div>
          <button
            onClick={startChallenge}
            id="start-challenge-btn"
            disabled={loading || !description.trim()}
            className="w-full bg-gradient-to-tr from-amber-600 to-orange-600 hover:from-amber-500 hover:to-orange-500 text-white font-black py-5 rounded-xl transition-all shadow-lg shadow-orange-900/20 disabled:opacity-50 text-xl active:scale-95"
          >
            {loading ? 'INITIALIZING...' : 'START CHALLENGE'}
          </button>
        </div>
      ) : (
        <div className="w-full flex flex-col items-center mt-4">
          {failedProof ? (
            <div className="w-full animate-in slide-in-from-bottom-8 duration-300">
               <div className="bg-red-600/10 border-2 border-red-600/30 p-8 rounded-3xl mb-8 flex flex-col items-center text-center shadow-2xl">
                  <AlertCircle className="w-16 h-16 text-red-500 mb-4" />
                  <h3 className="text-2xl font-black text-red-400 mb-2 uppercase">Proof Rejected</h3>
                  <p className="text-gray-300 mb-8 italic">"{failedProof.reason}"</p>
                  
                  <div className="flex flex-col sm:flex-row gap-4 w-full">
                    <button 
                      onClick={() => setFailedProof(null)}
                      className="flex-1 flex items-center justify-center gap-3 bg-purple-600 hover:bg-purple-700 text-white py-4 rounded-2xl font-black transition-all active:scale-95 shadow-lg shadow-purple-600/20"
                      id="continue-proof-btn"
                    >
                      <RefreshCw size={20} />
                      CONTINUE (TRY AGAIN)
                    </button>
                    <button 
                      onClick={() => handleGiveUp()}
                      className="flex-1 flex items-center justify-center gap-3 bg-red-600/20 hover:bg-red-600/30 text-red-400 py-4 rounded-2xl font-black border-2 border-red-600/40 transition-all active:scale-95"
                      id="give-up-btn"
                    >
                      <Trash2 size={20} />
                      GIVE UP (-100 PTS)
                    </button>
                  </div>
               </div>
            </div>
          ) : (
            <>
              <motion.div 
                key={timeLeft}
                initial={{ opacity: 0.5, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className={`font-mono text-9xl font-black mb-8 tracking-tighter ${timeLeft < 60 ? 'text-red-500 animate-pulse' : 'text-amber-500'}`}
              >
                {formatTime(timeLeft)}
              </motion.div>
              
              <div className="text-2xl font-black mb-12 text-center text-white bg-[#181520] py-6 px-10 rounded-3xl border border-[#2a2436] shadow-2xl max-w-md">
                "{description}"
              </div>
              
              <input
                type="file"
                accept="image/*,video/*"
                capture="environment"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileUpload}
              />
              
              <div className="flex flex-col gap-4 w-full max-w-sm">
                <button
                  onClick={() => fileInputRef.current?.click()}
                  id="submit-proof-btn"
                  disabled={loading}
                  className="group flex flex-col items-center gap-2 bg-gradient-to-tr from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 text-white px-8 py-6 rounded-3xl font-black text-2xl transition-all shadow-2xl shadow-indigo-900/30 disabled:opacity-50 active:scale-95 border-b-4 border-indigo-800"
                >
                  <div className="flex items-center gap-3">
                    <Camera size={32} />
                    <Video size={32} />
                  </div>
                  <span className="text-sm uppercase tracking-widest opacity-80 group-hover:opacity-100 italic">
                    {loading ? 'AI IS JUDGING...' : 'SUBMIT PROOF'}
                  </span>
                </button>
                
                {!loading && (
                   <button 
                    onClick={() => handleGiveUp()}
                    className="text-gray-500 hover:text-red-400 font-bold text-sm uppercase tracking-widest transition-colors py-2"
                   >
                     Giving Up?
                   </button>
                )}
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};
