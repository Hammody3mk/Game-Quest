import React, { useState, useEffect } from 'react';
import { Settings as SettingsIcon, Globe, Palette, QrCode, UserCircle } from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';
import { useAuth } from '../contexts/AuthContext';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';

export const Settings = () => {
  const { userProfile, currentUser, reloadProfile } = useAuth();
  const [lang, setLang] = useState(localStorage.getItem('gq_lang') || 'en');
  const [theme, setTheme] = useState(localStorage.getItem('gq_theme') || 'dark');

  const handleLangChange = (newLang: string) => {
    setLang(newLang);
    localStorage.setItem('gq_lang', newLang);
  };

  const handleThemeChange = (newTheme: string) => {
    setTheme(newTheme);
    localStorage.setItem('gq_theme', newTheme);
    document.documentElement.setAttribute('data-theme', newTheme);
  };

  const overrideAvatar = async (url: string) => {
    if (!currentUser) return;
    try {
      await updateDoc(doc(db, 'users', currentUser.uid), {
        avatar: url,
        updatedAt: serverTimestamp()
      });
      await reloadProfile();
      alert('Avatar updated!');
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  useEffect(() => {
    document.documentElement.setAttribute('data-theme', theme);
  }, [theme]);

  const [notifMultiplayer, setNotifMultiplayer] = useState(localStorage.getItem('gq_notif_multi') !== 'false');
  const [notifAdmin, setNotifAdmin] = useState(localStorage.getItem('gq_notif_admin') !== 'false');
  const [notifDepth, setNotifDepth] = useState(localStorage.getItem('gq_notif_depth') !== 'false');

  const toggleNotif = (key: string, setter: any, val: boolean) => {
    setter(val);
    localStorage.setItem(key, val.toString());
    if (val && 'Notification' in window) {
      Notification.requestPermission();
    }
  };

  const t = {
    en: { settings: 'Settings', lang: 'Language', theme: 'Theme', langDesc: 'Choose your preferred language', themeDesc: 'Customize the look of GameQuest', avatar: 'Supreme Avatar', avatarDesc: 'Choose your unlocked avatar' },
    es: { settings: 'Ajustes', lang: 'Idioma', theme: 'Tema', langDesc: 'Elige tu idioma', themeDesc: 'Personaliza el aspecto', avatar: 'Avatar Supremo', avatarDesc: 'Elige tu avatar' },
    fr: { settings: 'Paramètres', lang: 'Langue', theme: 'Thème', langDesc: 'Choisissez la langue', themeDesc: 'Personnaliser l\'apparence', avatar: 'Avatar Suprême', avatarDesc: 'Choisissez votre avatar' },
    ar: { settings: 'الإعدادات', lang: 'اللغة', theme: 'السمة', langDesc: 'اختر لغتك المفضلة', themeDesc: 'تخصيص مظهر اللعبة', avatar: 'أفاتار سوبريم', avatarDesc: 'اختر الأفاتار الخاص بك' },
  }[lang] || { settings: 'Settings', lang: 'Language', theme: 'Theme', langDesc: 'Choose language', themeDesc: 'Customize theme', avatar: 'Supreme Avatar', avatarDesc: 'Choose your unlocked avatar' };

  return (
    <div className={`p-10 flex flex-col h-full max-w-3xl mx-auto w-full text-white ${lang === 'ar' ? 'text-right' : 'text-left'}`}>
      <div className="flex items-center gap-4 mb-10">
        <div className="bg-gray-600/20 p-3 rounded-xl">
          <SettingsIcon className="w-8 h-8 text-gray-400" />
        </div>
        <h2 className="text-3xl font-bold">{t.settings}</h2>
      </div>

      <div className="space-y-6">
        {userProfile?.inventory?.some(i => i.startsWith('supreme_avatar')) && (
          <div className="bg-[#181520] border border-fuchsia-500/50 p-6 rounded-2xl flex flex-col shadow-[0_0_15px_rgba(217,70,239,0.1)]">
            <div className={`flex items-center gap-4 mb-4 ${lang === 'ar' ? 'flex-row-reverse' : ''}`}>
              <UserCircle className="text-fuchsia-400 w-8 h-8" />
              <div>
                <h3 className="font-bold text-fuchsia-400">{t.avatar}</h3>
                <p className="text-sm text-gray-400">{t.avatarDesc}</p>
              </div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
               {userProfile.inventory.includes('supreme_avatar_1') && (
                 <button onClick={() => overrideAvatar('https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=150&q=80')} className={`rounded-full border-4 overflow-hidden w-24 h-24 transition-all ${userProfile.avatar?.includes('1550745') ? 'border-fuchsia-500 scale-110' : 'border-transparent hover:border-white/20'}`}>
                   <img src="https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=150&q=80" alt="Neon" className="w-full h-full object-cover" />
                 </button>
               )}
               {userProfile.inventory.includes('supreme_avatar_2') && (
                 <button onClick={() => overrideAvatar('https://images.unsplash.com/photo-1614729939124-032f0b56c9ce?w=150&q=80')} className={`rounded-full border-4 overflow-hidden w-24 h-24 transition-all ${userProfile.avatar?.includes('1614729') ? 'border-fuchsia-500 scale-110' : 'border-transparent hover:border-white/20'}`}>
                   <img src="https://images.unsplash.com/photo-1614729939124-032f0b56c9ce?w=150&q=80" alt="Synth" className="w-full h-full object-cover" />
                 </button>
               )}
            </div>
          </div>
        )}
        <div className={`bg-[#181520] border border-[#2a2436] p-6 rounded-2xl flex items-center justify-between ${lang === 'ar' ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-4 ${lang === 'ar' ? 'flex-row-reverse' : ''}`}>
            <Globe className="text-gray-400" />
            <div>
              <h3 className="font-bold">{t.lang}</h3>
              <p className="text-sm text-gray-400">{t.langDesc}</p>
            </div>
          </div>
          <select 
            value={lang} 
            onChange={(e) => handleLangChange(e.target.value)}
            className="bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-2 outline-none focus:border-purple-500"
          >
            <option value="en">English</option>
            <option value="ar">Arabic (العربية)</option>
            <option value="es">Spanish (Español)</option>
            <option value="fr">French (Français)</option>
          </select>
        </div>

        <div className={`bg-[#181520] border border-[#2a2436] p-6 rounded-2xl flex items-center justify-between ${lang === 'ar' ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-4 ${lang === 'ar' ? 'flex-row-reverse' : ''}`}>
            <Palette className="text-gray-400" />
            <div>
              <h3 className="font-bold">{t.theme}</h3>
              <p className="text-sm text-gray-400">{t.themeDesc}</p>
            </div>
          </div>
          <select 
            value={theme} 
            onChange={(e) => handleThemeChange(e.target.value)}
            className="bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-2 outline-none focus:border-purple-500"
          >
            <option value="dark">Dark Neon (Default)</option>
            <option value="light">Light Mode</option>
            <option value="hacker">Hacker Green</option>
          </select>
        </div>

        <div className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl flex flex-col mt-4">
           <h3 className="font-bold text-xl mb-4 border-b border-[#3b334d] pb-2">Notification Preferences</h3>
           <div className="space-y-4">
             <div className="flex items-center justify-between">
               <div>
                 <div className="font-bold">Multiplayer</div>
                 <div className="text-xs text-gray-400">Alerts for friends and challenges</div>
               </div>
               <input type="checkbox" checked={notifMultiplayer} onChange={(e) => toggleNotif('gq_notif_multi', setNotifMultiplayer, e.target.checked)} className="w-5 h-5 accent-purple-500" />
             </div>
             <div className="flex items-center justify-between">
               <div>
                 <div className="font-bold">Admin Gifts</div>
                 <div className="text-xs text-gray-400">Alerts when you receive points from an admin</div>
               </div>
               <input type="checkbox" checked={notifAdmin} onChange={(e) => toggleNotif('gq_notif_admin', setNotifAdmin, e.target.checked)} className="w-5 h-5 accent-purple-500" />
             </div>
             <div className="flex items-center justify-between">
               <div>
                 <div className="font-bold">Depth Debt</div>
                 <div className="text-xs text-gray-400">Alerts for Depth payment logic</div>
               </div>
               <input type="checkbox" checked={notifDepth} onChange={(e) => toggleNotif('gq_notif_depth', setNotifDepth, e.target.checked)} className="w-5 h-5 accent-purple-500" />
             </div>
           </div>
        </div>
      </div>
    </div>
  );
};
