import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { AlertTriangle, TrendingDown, CheckCircle, Clock } from 'lucide-react';
import { motion } from 'framer-motion';

export const Depth = () => {
  const { userProfile, currentUser, reloadProfile } = useAuth();
  const [payAmount, setPayAmount] = useState<number | ''>('');
  const [paySource, setPaySource] = useState<'quiz' | 'challenge'>('quiz');
  const [loading, setLoading] = useState(false);

  if (!userProfile) return null;

  const currentDepth = userProfile.depth || 0;

  const maxFromSource = paySource === 'quiz' ? userProfile.quizPoints : userProfile.challengePoints;

  const handlePay = async () => {
    if (!currentUser || !payAmount || payAmount <= 0) return;
    if (payAmount > currentDepth) {
      alert("You cannot pay more than you owe!");
      return;
    }
    if (payAmount > maxFromSource) {
      alert(`You don't have enough ${paySource} points!`);
      return;
    }

    setLoading(true);
    try {
      const updates: any = {
        depth: currentDepth - payAmount,
        updatedAt: serverTimestamp(),
      };
      if (paySource === 'quiz') {
        updates.quizPoints = userProfile.quizPoints - payAmount;
      } else {
        updates.challengePoints = userProfile.challengePoints - payAmount;
      }
      
      await updateDoc(doc(db, 'users', currentUser.uid), updates);
      await reloadProfile();
      setPayAmount('');
      alert(`Successfully paid $${payAmount} towards your depth!`);
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${currentUser.uid}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="p-10 flex flex-col items-center h-full max-w-4xl mx-auto w-full text-white">
      <div className="flex items-center gap-4 mb-2">
        <div className="bg-red-600/20 p-4 rounded-full">
          <TrendingDown className="w-12 h-12 text-red-500" />
        </div>
        <h2 className="text-4xl font-bold">Debt Center</h2>
      </div>
      <p className="text-gray-400 mb-10 text-center">Manage your debts. Unpaid debts accrue strict penalties.</p>

      {currentDepth > 0 ? (
        <div className="w-full bg-[#181520] border-2 border-red-500/50 p-8 rounded-2xl shadow-[0_0_50px_rgba(239,68,68,0.1)]">
          <div className="flex flex-col items-center mb-10">
            <h3 className="text-xl font-bold text-red-500 uppercase tracking-widest mb-2">Outstanding Debt</h3>
            <motion.div 
              initial={{ scale: 0.9 }}
              animate={{ scale: 1 }}
              className="font-mono text-8xl font-bold text-white tracking-tighter"
            >
              ${currentDepth}
            </motion.div>
            <div className="mt-4 flex items-center gap-2 text-amber-500 bg-amber-500/10 px-4 py-2 rounded-lg font-bold">
              <Clock size={18} />
              Warning: Debt multiples by 3x every 3 hours if unpaid!
            </div>
          </div>

          <div className="bg-[#0b090f] p-6 rounded-xl border border-[#2a2436]">
            <h4 className="text-lg font-bold mb-4">Make a Payment</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
              <div>
                <label className="block text-gray-400 text-sm font-bold mb-2">Amount to Pay</label>
                <input
                  type="number"
                  min="1"
                  max={Math.min(currentDepth, maxFromSource)}
                  value={payAmount}
                  onChange={(e) => setPayAmount(Number(e.target.value))}
                  placeholder="Enter amount..."
                  className="w-full bg-[#181520] border border-[#2a2436] rounded-xl px-4 py-4 text-white focus:outline-none focus:border-red-500 transition-colors"
                />
                <div className="mt-2 text-xs text-gray-400 flex gap-2">
                  <button onClick={() => setPayAmount(Math.min(currentDepth, Math.floor(currentDepth / 2), maxFromSource))} className="hover:text-white underline">Pay Half</button>
                  <button onClick={() => setPayAmount(Math.min(currentDepth, maxFromSource))} className="hover:text-white underline">Pay Max Possible</button>
                </div>
              </div>
              
              <div>
                <label className="block text-gray-400 text-sm font-bold mb-2">Payment Source</label>
                <select
                  value={paySource}
                  onChange={(e: any) => setPaySource(e.target.value)}
                  className="w-full bg-[#181520] border border-[#2a2436] rounded-xl px-4 py-4 text-white focus:outline-none focus:border-red-500 transition-colors cursor-pointer"
                >
                  <option value="quiz">Quiz Points (Available: {userProfile.quizPoints})</option>
                  <option value="challenge">Challenge Points (Available: {userProfile.challengePoints})</option>
                </select>
              </div>
            </div>

            <button
              onClick={handlePay}
              disabled={loading || !payAmount || payAmount <= 0}
              className="w-full bg-red-600 hover:bg-red-700 text-white font-bold py-4 rounded-xl transition-colors shadow-lg shadow-red-900/20 disabled:opacity-50"
            >
              {loading ? 'Processing...' : 'Submit Payment'}
            </button>
          </div>
        </div>
      ) : (
        <div className="flex flex-col items-center justify-center p-16 bg-[#181520] border border-[#2a2436] rounded-2xl w-full">
          <CheckCircle className="w-20 h-20 text-green-500 mb-6" />
          <h3 className="text-2xl font-bold text-white mb-2">You are debt-free!</h3>
          <p className="text-gray-400 text-center">Your account is in good standing. Keep completing challenges to earn more points!</p>
        </div>
      )}
    </div>
  );
};
