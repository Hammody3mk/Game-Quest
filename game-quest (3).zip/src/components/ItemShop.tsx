import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { doc, updateDoc, serverTimestamp, collection, query, where, getDocs } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { ShoppingBag, Lock, Zap, Gift, Target, Sparkles, Send } from 'lucide-react';

const ITEMS = [
  { id: 'supreme_avatar_1', name: 'Supreme Avatar (Neon)', desc: 'Unlock a special glowing neon avatar', price: 2000, type: 'challenge', icon: Sparkles, image: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=400&q=80' },
  { id: 'supreme_avatar_2', name: 'Supreme Avatar (Synth)', desc: 'Retro synthwave avatar profile', price: 2000, type: 'challenge', icon: Sparkles, image: 'https://images.unsplash.com/photo-1614729939124-032f0b56c9ce?w=400&q=80' },
  { id: 'xp_booster', name: 'XP Booster', desc: 'Double your points for 1 hour', price: 500, type: 'quiz', icon: Zap, image: 'https://images.unsplash.com/photo-1614730321146-b6fa6a46bcb4?w=400&q=80' },
  { id: 'mystery_gift', name: 'Mystery Gift', desc: 'Send a random prize to someone', price: 300, type: 'quiz', icon: Gift, image: 'https://images.unsplash.com/photo-1513201099705-a9746e1e201f?w=400&q=80' },
  { id: 'target_lock', name: 'Target Lock', desc: 'Guarantees the next challenge target', price: 1000, type: 'challenge', icon: Target, image: 'https://images.unsplash.com/photo-1555680202-c86f0e12f086?w=400&q=80' },
];

export const ItemShop = () => {
  const { userProfile, currentUser, reloadProfile } = useAuth();
  const [giftMode, setGiftMode] = useState<string | null>(null);
  const [friendUsername, setFriendUsername] = useState('');
  
  const buyItem = async (item: any, isGift: boolean = false) => {
    if (!userProfile || !currentUser) return;
    
    if (item.type === 'quiz' && userProfile.quizPoints < item.price) {
      alert('Not enough Quiz Points!');
      return;
    }
    if (item.type === 'challenge' && userProfile.challengePoints < item.price) {
      alert('Not enough Challenge Points!');
      return;
    }

    let targetUserId = currentUser.uid;
    let targetInventory = userProfile.inventory || [];

    if (isGift) {
      if (!friendUsername.trim()) {
        alert('Please enter a friend username!');
        return;
      }
      try {
        const q = query(collection(db, 'users'), where('username', '==', friendUsername.trim()));
        const snap = await getDocs(q);
        if (snap.empty) {
          alert('User not found!');
          return;
        }
        const friendDoc = snap.docs[0];
        targetUserId = friendDoc.id;
        targetInventory = friendDoc.data().inventory || [];
      } catch (e) {
        handleFirestoreError(e, OperationType.GET, 'users');
        return;
      }
    } else {
      if (targetInventory.includes(item.id)) {
        alert('You already own this item!');
        return;
      }
    }

    try {
      // Deduct points from buyer
      const buyerRef = doc(db, 'users', currentUser.uid);
      const updates: any = { updatedAt: serverTimestamp() };
      if (item.type === 'quiz') {
        updates.quizPoints = userProfile.quizPoints - item.price;
      } else {
        updates.challengePoints = userProfile.challengePoints - item.price;
      }

      // Add item to target (either buyer or friend)
      if (targetUserId === currentUser.uid) {
        updates.inventory = [...targetInventory, item.id];
        await updateDoc(buyerRef, updates);
      } else {
        // Buy for friend (2 writes)
        await updateDoc(buyerRef, updates);
        const friendRef = doc(db, 'users', targetUserId);
        await updateDoc(friendRef, { inventory: [...targetInventory, item.id], updatedAt: serverTimestamp() });
      }

      await reloadProfile();
      setGiftMode(null);
      setFriendUsername('');
      if (isGift) {
        alert(`Successfully sent ${item.name} to ${friendUsername}!`);
      } else {
        alert(`Successfully purchased ${item.name}!`);
      }
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users`);
    }
  };

  return (
    <div className="p-10 flex flex-col h-full max-w-6xl mx-auto w-full text-white">
      <div className="flex items-center justify-between mb-10">
        <div className="flex items-center gap-4">
          <div className="bg-fuchsia-600/20 p-3 rounded-xl">
            <ShoppingBag className="w-8 h-8 text-fuchsia-500" />
          </div>
          <h2 className="text-3xl font-bold">Item Shop</h2>
        </div>
        
        <div className="flex gap-4">
          <div className="bg-[#181520] border border-[#2a2436] px-6 py-2 rounded-xl flex flex-col items-end">
            <span className="text-gray-400 font-bold uppercase text-[10px]">Quiz Points</span>
            <div className="text-xl font-black text-white">{userProfile?.quizPoints}</div>
          </div>
          <div className="bg-[#181520] border border-[#2a2436] px-6 py-2 rounded-xl flex flex-col items-end">
            <span className="text-gray-400 font-bold uppercase text-[10px]">Challenge Pts</span>
            <div className="text-xl font-black text-amber-500">{userProfile?.challengePoints}</div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {ITEMS.map(item => {
          const isOwned = !giftMode && userProfile?.inventory?.includes(item.id);
          const isGiftingThis = giftMode === item.id;

          return (
            <div key={item.id} className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl flex flex-col hover:border-fuchsia-500 transition-colors relative overflow-hidden group">
              <div 
                className="absolute inset-0 bg-cover bg-center opacity-20 group-hover:opacity-40 transition-opacity"
                style={{ backgroundImage: `url(${item.image})` }}
              />
              <div className="relative z-10 flex flex-col h-full">
                <div className="bg-[#211d2b]/80 backdrop-blur-md w-14 h-14 rounded-xl mb-4 flex items-center justify-center border border-white/10">
                  <item.icon className="w-6 h-6 text-fuchsia-400" />
                </div>
                <h3 className="font-bold text-xl mb-1 text-white drop-shadow-md">{item.name}</h3>
                <p className="text-sm text-gray-300 mb-6 flex-grow drop-shadow-md">{item.desc}</p>
                
                {isGiftingThis ? (
                  <div className="flex flex-col gap-2 mt-auto">
                    <input 
                      type="text" 
                      placeholder="Friend's username..."
                      value={friendUsername}
                      onChange={e => setFriendUsername(e.target.value)}
                      className="bg-[#0b090f] border border-[#3b334d] px-4 py-2 rounded-lg text-sm focus:outline-none focus:border-fuchsia-500"
                    />
                    <div className="flex gap-2">
                       <button onClick={() => buyItem(item, true)} className="flex-1 bg-fuchsia-600 hover:bg-fuchsia-700 py-2 rounded-lg font-bold text-sm transition-colors">Send</button>
                       <button onClick={() => setGiftMode(null)} className="flex-1 bg-[#2a2436] hover:bg-[#3b334d] py-2 rounded-lg font-bold text-sm transition-colors">Cancel</button>
                    </div>
                  </div>
                ) : (
                  <div className="flex items-center gap-2 mt-auto">
                    <button 
                        onClick={() => setGiftMode(item.id)}
                        className="bg-[#211d2b] hover:bg-[#2a2436] border border-[#3b334d] p-3 rounded-xl font-bold transition-colors"
                        title="Gift to a friend"
                      >
                        <Send size={16} className="text-fuchsia-400" />
                    </button>
                    <button 
                      onClick={() => buyItem(item)}
                      disabled={isOwned}
                      className={`flex-grow border py-3 rounded-xl font-bold transition-colors flex items-center justify-center gap-2 ${isOwned ? 'bg-emerald-600/20 border-emerald-500/50 text-emerald-400' : 'bg-[#211d2b] hover:bg-fuchsia-600 border-[#3b334d] hover:border-fuchsia-500'}`}
                    >
                      {isOwned ? (
                        'Owned'
                      ) : (
                        <>
                          <Lock size={16} /> 
                          {item.price} {item.type === 'quiz' ? 'Q-Pts' : 'C-Pts'}
                        </>
                      )}
                    </button>
                  </div>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  );
};
