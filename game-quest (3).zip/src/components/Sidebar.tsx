import React from 'react';
import { NavLink } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { LayoutDashboard, Brain, Swords, Users, ShoppingBag, Wrench, Settings, ShieldAlert, LogOut, RefreshCcw } from 'lucide-react';
import { getDisplayRank } from '../lib/ranks';

const navItems: Array<{ icon: any, label: string, path: string, className?: string }> = [
  { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
  { icon: Brain, label: 'Quiz Game', path: '/quiz' },
  { icon: Swords, label: 'Challenge Me', path: '/challenge' },
  { icon: Users, label: 'Multiplayer', path: '/multiplayer' },
  { icon: ShoppingBag, label: 'Item Shop', path: '/shop' },
  { icon: RefreshCcw, label: 'Depth', path: '/depth', className: 'text-red-400 font-bold' },
  { icon: Settings, label: 'Settings', path: '/settings' },
  { icon: ShieldAlert, label: 'Admin Panel', path: '/admin', className: 'text-amber-400' },
];

export const Sidebar = () => {
  const { userProfile, logout } = useAuth();
  
  const allNavItems = [...navItems];

  return (
    <div className="w-64 bg-[#110f17] h-screen p-4 flex flex-col text-gray-300">
      <div className="flex items-center gap-2 mb-8 px-2">
        <div className="bg-purple-600 p-2 rounded-lg">
          <Brain className="text-white" />
        </div>
        <span className="text-xl font-bold text-white tracking-tight">GAME QUEST</span>
      </div>
      
      <div className="text-xs font-semibold uppercase tracking-wider text-gray-500 mb-4 px-2">Navigation</div>
      
      <nav className="flex flex-col gap-1 flex-grow">
        {allNavItems.map((item) => (
          <NavLink
            key={item.label}
            to={item.path}
            className={({ isActive }) => `flex items-center gap-3 px-3 py-2 rounded-lg transition-colors ${
              isActive ? 'bg-[#211d2b] text-purple-400' : 'hover:bg-[#1a1721] hover:text-white'
            } ${(item as any).className || ''}`}
          >
            {React.createElement(item.icon, { size: 20 })}
            {item.label}
          </NavLink>
        ))}
      </nav>

      <div className="mt-auto border-t border-gray-800 pt-4">
        {userProfile && (
          <div className="flex items-center gap-3 px-3 py-3 rounded-lg bg-[#1a1721] mb-4">
            {userProfile.avatar ? (
              <img src={userProfile.avatar} alt="Avatar" className="w-10 h-10 rounded-full border-2 border-fuchsia-500 object-cover" />
            ) : (
              <div className="w-10 h-10 rounded-full bg-purple-600 flex items-center justify-center font-bold text-sm">
                {userProfile.username.charAt(0).toUpperCase()}
              </div>
            )}
            <div>
              <div className="text-sm font-semibold text-white truncate w-32">{userProfile.username}</div>
              <div className="text-xs text-purple-400 truncate w-32" title={getDisplayRank(userProfile)}>✨ {getDisplayRank(userProfile)}</div>
            </div>
          </div>
        )}
        
        <button onClick={logout} className="w-full flex items-center gap-3 px-3 py-2 text-gray-400 hover:text-white">
          <LogOut size={18} /> Sign Out
        </button>
      </div>
    </div>
  );
};
