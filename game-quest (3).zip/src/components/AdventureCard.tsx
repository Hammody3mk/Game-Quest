import React from 'react';
import { Link } from 'react-router-dom';
import { Brain, Swords, ShoppingBag, Skull } from 'lucide-react';

export const AdventureCard = ({ icon: Icon, title, desc, to }: { icon: any, title: string, desc: string, to: string }) => (
  <Link to={to} className="block w-full h-full">
    <div className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl flex flex-col items-center text-center gap-4 hover:border-purple-500 transition-colors h-full">
      <div className="bg-[#211d2b] p-4 rounded-xl">
        <Icon size={32} className="text-purple-400" />
      </div>
      <h3 className="text-xl font-bold text-white">{title}</h3>
      <p className="text-sm text-gray-400">{desc}</p>
    </div>
  </Link>
);

export const ComingSoonCard = () => (
  <div className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl flex flex-col items-center text-center gap-4">
    <div className="bg-[#211d2b] p-4 rounded-xl">
      <Skull size={32} className="text-purple-400" />
    </div>
    <h3 className="text-xl font-bold text-white">Poison Store</h3>
    <p className="text-sm text-gray-400">Use special items against your opponents</p>
    <div className="bg-[#211d2b] text-purple-400 px-4 py-1 rounded-full text-xs font-semibold">Coming Soon</div>
  </div>
);
