import React, { useState } from 'react';
import { createUserWithEmailAndPassword, signInWithEmailAndPassword } from 'firebase/auth';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Brain } from 'lucide-react';

export const AuthScreen = () => {
  const [isLogin, setIsLogin] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [username, setUsername] = useState('');
  const [error, setError] = useState('');
  const { reloadProfile } = useAuth();
  
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      if (isLogin) {
        await signInWithEmailAndPassword(auth, email, password);
      } else {
        if (!username.trim()) throw new Error('Username is required');
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        const user = userCredential.user;
        
        // Create user profile
        try {
          await setDoc(doc(db, 'users', user.uid), {
            email: user.email,
            username: username.trim(),
            quizPoints: 0,
            challengePoints: 0,
            rank: 'Bronze',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        } catch (err) {
          handleFirestoreError(err, OperationType.CREATE, `users/${user.uid}`);
        }
      }
      await reloadProfile();
      
      // Request notification permission
      if ('Notification' in window) {
        try {
          const perm = await Notification.requestPermission();
          if (perm === 'granted') {
            const { getDoc, doc } = await import('firebase/firestore');
            const uid = auth.currentUser?.uid;
            if (uid) {
               const userDoc = await getDoc(doc(db, 'users', uid));
               const data = userDoc.data();
               if (data && (data.challengePoints < 0 || data.quizPoints < 0)) {
                  new Notification("Game Quest Debt Alert", {
                     body: "You are in debt! You need to win games or complete challenges to pay it off."
                  });
               } else {
                  new Notification("Game Quest", {
                     body: "Welcome to Game Quest! Notifications enabled."
                  });
               }
            }
          }
        } catch (e) {
          console.error("Failed to request notification permission", e);
        }
      }
    } catch (err: any) {
      setError(err.message || 'An error occurred during authentication.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b090f] flex items-center justify-center p-4">
      <div className="bg-[#181520] border border-[#2a2436] p-8 rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-purple-600 p-4 rounded-2xl mb-4">
            <Brain className="text-white w-10 h-10" />
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Game Quest</h1>
          <p className="text-gray-400 mt-2 text-sm text-center">
            {isLogin ? 'Welcome back, Gamer!' : 'Start your adventure today.'}
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-lg mb-4 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-400 text-xs font-semibold mb-1 uppercase tracking-wide">Email</label>
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors"
              placeholder="gamer@example.com"
              required
            />
          </div>
          
          {!isLogin && (
            <div>
              <label className="block text-gray-400 text-xs font-semibold mb-1 uppercase tracking-wide">Username</label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors"
                placeholder="EpicGamer123"
                required={!isLogin}
              />
            </div>
          )}

          <div>
            <label className="block text-gray-400 text-xs font-semibold mb-1 uppercase tracking-wide">Password</label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors"
              placeholder="••••••••"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-xl transition-colors disabled:opacity-50 mt-4"
          >
            {loading ? 'Processing...' : (isLogin ? 'Join Game' : 'Create Account')}
          </button>
        </form>

        <div className="mt-6 text-center">
          <p className="text-gray-400 text-sm">
            {isLogin ? "Don't have an account?" : "Already have an account?"}{' '}
            <button
              onClick={() => setIsLogin(!isLogin)}
              className="text-purple-400 hover:text-purple-300 font-semibold"
            >
              {isLogin ? 'Sign Up' : 'Log In'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
};
