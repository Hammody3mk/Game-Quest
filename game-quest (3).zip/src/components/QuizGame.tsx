import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { generateQuizQuestions } from '../lib/gemini';
import { doc, updateDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Brain, Coins, X } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { getRankInfo, getDisplayRank } from '../lib/ranks';

const LOCAL_STORAGE_KEY = 'gq_quiz_state';

export const QuizGame = () => {
  const { userProfile, currentUser, reloadProfile, activeEvents } = useAuth();
  const [loading, setLoading] = useState(false);
  const [questions, setQuestions] = useState<any[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  
  const [selectedAnswerIndex, setSelectedAnswerIndex] = useState<number | null>(null);
  const [isAnswering, setIsAnswering] = useState(false);
  const [showCoinRain, setShowCoinRain] = useState(false);
  const [showResumePrompt, setShowResumePrompt] = useState(false);
  const [showQuitConfirm, setShowQuitConfirm] = useState(false);

  const [errorStatus, setErrorStatus] = useState<string | null>(null);

  useEffect(() => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const state = JSON.parse(saved);
        if (state.questions && state.questions.length > 0 && !state.gameOver) {
          setShowResumePrompt(true);
        }
      } catch (e) {}
    }
  }, []);

  useEffect(() => {
    if (questions.length > 0 && !gameOver) {
      localStorage.setItem(LOCAL_STORAGE_KEY, JSON.stringify({
        questions,
        currentIndex,
        score,
        gameOver
      }));
    } else if (gameOver) {
      localStorage.removeItem(LOCAL_STORAGE_KEY);
    }
  }, [questions, currentIndex, score, gameOver]);

  // Calculate generic multiplier based on active events
  const hasDouble = activeEvents.some(e => e.id === 'double_coins');
  const hasStorm = activeEvents.some(e => e.id === 'xp_storm');
  let multiplier = 1;
  if (hasDouble) multiplier *= 2;
  if (hasStorm) multiplier *= 3;

  const resumeGame = () => {
    const saved = localStorage.getItem(LOCAL_STORAGE_KEY);
    if (saved) {
      try {
        const state = JSON.parse(saved);
        setQuestions(state.questions);
        setCurrentIndex(state.currentIndex);
        setScore(state.score);
        setGameOver(state.gameOver);
      } catch (e) {
        setErrorStatus("Could not resume game.");
        localStorage.removeItem(LOCAL_STORAGE_KEY);
      }
    }
    setShowResumePrompt(false);
  };

  const startNewGame = () => {
    localStorage.removeItem(LOCAL_STORAGE_KEY);
    setShowResumePrompt(false);
    setQuestions([]);
    setGameOver(false);
    setErrorStatus(null);
  };

  const startGame = async (mode: 'casual' | 'ranked') => {
    setLoading(true);
    setErrorStatus(null);
    try {
      const { currentRank } = getRankInfo(userProfile?.quizPoints || 0);
      const count = mode === 'casual' ? 30 : 10;
      const difficulty = mode === 'ranked' ? 'hard' : 'medium';
      const generated = await generateQuizQuestions(difficulty, count, currentRank.name);
      if (!generated || generated.length === 0) {
        throw new Error("The quiz master is busy. Please try again in a moment.");
      }
      setQuestions(generated);
      setCurrentIndex(0);
      setScore(0);
      setGameOver(false);
    } catch (err: any) {
      console.error(err);
      setErrorStatus(err.message || "Failed to start quiz. Check your connection or API key.");
    } finally {
      setLoading(false);
    }
  };

  const answerQuestion = (index: number) => {
    if (isAnswering) return;
    setIsAnswering(true);
    setSelectedAnswerIndex(index);
    
    const isCorrect = index === questions[currentIndex].correctAnswerIndex;
    if (isCorrect) {
      setScore(score + 1);
      setShowCoinRain(true);
    }

    setTimeout(() => {
      setSelectedAnswerIndex(null);
      setIsAnswering(false);
      setShowCoinRain(false);
      if (currentIndex + 1 < questions.length) {
        setCurrentIndex(currentIndex + 1);
      } else {
        finishGame(score + (isCorrect ? 1 : 0));
      }
    }, 2000);
  };

  const finishGame = async (finalScore: number) => {
    setGameOver(true);
    if (!currentUser || !userProfile) return;

    try {
      const pointsEarned = finalScore * 10 * multiplier;
      const userRef = doc(db, 'users', currentUser.uid);
      await updateDoc(userRef, {
        quizPoints: userProfile.quizPoints + pointsEarned,
        updatedAt: serverTimestamp(),
      });
      await reloadProfile();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, `users/${currentUser.uid}`);
    }
  };

  if (loading) return <div className="p-10 text-white">Generating Epic Quiz...</div>;

  if (questions.length === 0) {
    const { currentRank, nextRank } = getRankInfo(userProfile?.quizPoints || 0);
    const displayRank = getDisplayRank(userProfile);
    const progressText = nextRank 
        ? `${userProfile?.quizPoints} / ${nextRank.min} pts to ${nextRank.name}` 
        : `Max Rank Reached!`;

    const isHighRank = ['Gold', 'Platinum', 'Diamond'].includes(currentRank.name);

    return (
      <div className="p-10 flex flex-col items-center justify-center h-full">
        <Brain className="w-20 h-20 text-purple-500 mb-6" />
        <h2 className="text-3xl font-black text-white mb-4 uppercase tracking-tighter">Quiz Hub</h2>
        
        {errorStatus && (
          <div className="bg-red-500/20 border border-red-500 text-red-200 px-4 py-2 rounded-lg mb-6 max-w-md text-center">
            {errorStatus}
          </div>
        )}

        {showResumePrompt && (
          <div className="bg-purple-600/20 border border-purple-500/50 p-4 rounded-xl mb-8 flex items-center justify-between w-full max-w-md animate-in fade-in slide-in-from-top-4">
            <span className="text-white text-sm font-medium">Unfinished game found!</span>
            <div className="flex gap-2">
              <button 
                onClick={resumeGame} 
                className="bg-purple-600 hover:bg-purple-700 text-white text-xs px-3 py-1.5 rounded-lg font-bold transition-colors"
              >
                Resume
              </button>
              <button 
                onClick={startNewGame} 
                className="bg-red-600/20 hover:bg-red-600/40 text-red-400 text-xs px-3 py-1.5 rounded-lg font-bold transition-colors"
              >
                Discard
              </button>
            </div>
          </div>
        )}

        {multiplier > 1 && (
          <div className="bg-amber-500 text-black font-black px-4 py-1 rounded-full mb-6 animate-bounce shadow-lg shadow-amber-500/20 text-xs uppercase tracking-widest">
            EVENT ACTIVE: {multiplier}x POINTS!
          </div>
        )}

        <div className="bg-[#181520] border border-[#2a2436] p-8 rounded-3xl flex flex-col items-center mb-8 w-full max-w-md shadow-2xl relative overflow-hidden">
           {isHighRank && (
             <div className="absolute top-0 left-0 w-full h-1 bg-gradient-to-r from-transparent via-purple-500 to-transparent animate-pulse" />
           )}
           <div className="text-gray-500 text-xs font-black uppercase tracking-widest mb-3">Your Player Tier</div>
           <div className={`text-5xl font-black mb-2 tracking-tighter ${isHighRank ? 'text-transparent bg-clip-text bg-gradient-to-b from-purple-400 to-fuchsia-600 animate-pulse' : 'text-purple-400'}`}>
             {displayRank}
           </div>
           <div className="text-sm text-gray-500 font-bold mb-4">{progressText}</div>
           
           <div className="w-full bg-[#0b090f] rounded-full h-2 mb-2 overflow-hidden border border-white/5">
              <motion.div 
                initial={{ width: 0 }}
                animate={{ width: nextRank ? `${((userProfile?.quizPoints || 0) / nextRank.min) * 100}%` : '100%' }}
                className="h-full bg-purple-500"
              />
           </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full max-w-2xl">
          <button 
            onClick={() => startGame('casual')} 
            className="group bg-[#181520] hover:bg-purple-600/10 border-2 border-[#2a2436] hover:border-purple-500/50 p-6 rounded-2xl flex flex-col items-center transition-all hover:-translate-y-1"
            id="start-casual-btn"
          >
            <span className="text-xl font-black text-white group-hover:text-purple-400 mb-1 uppercase tracking-tight">Casual Play</span>
            <span className="text-xs text-gray-500 font-bold uppercase tracking-widest italic group-hover:text-purple-300/50">Fusion Mode (30 Questions)</span>
          </button>
          
          <button 
            onClick={() => startGame('ranked')} 
            className="group relative bg-gradient-to-tr from-purple-600 to-fuchsia-700 hover:from-purple-500 hover:to-fuchsia-600 p-6 rounded-2xl flex flex-col items-center transition-all hover:-translate-y-1 shadow-xl shadow-purple-900/20 active:scale-95"
            id="start-ranked-btn"
          >
            <div className="absolute -top-3 bg-white text-black text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-tighter shadow-lg">
              {isHighRank ? 'Expert Level' : 'Hard Mode'}
            </div>
            <span className="text-xl font-black text-white mb-1 uppercase tracking-tight">Enter Arena</span>
            <span className="text-xs text-purple-100/70 font-bold uppercase tracking-widest italic">
              10 Ranked Expert Questions
            </span>
          </button>
        </div>
      </div>
    );
  }

  if (gameOver) {
    return (
      <div className="p-10 flex flex-col items-center justify-center h-full text-white">
        <h2 className="text-4xl font-bold text-white mb-4">Quiz Finished!</h2>
        <p className="text-2xl mb-8">You scored {score} out of {questions.length}</p>
        <p className="text-purple-400 font-bold mb-8">+{score * 10 * multiplier} Quiz Points added! {multiplier > 1 ? `(${multiplier}x Boost!)` : ''}</p>
        <button onClick={startNewGame} className="bg-purple-600 hover:bg-purple-700 text-white px-8 py-3 rounded-xl font-bold transition-colors">
          Return to Hub
        </button>
      </div>
    );
  }

  const q = questions[currentIndex];
  const displayRank = getDisplayRank(userProfile);
  const isHighRank = ['Gold', 'Platinum', 'Diamond'].includes(displayRank);

  return (
    <div className="p-10 flex flex-col items-center h-full text-white max-w-3xl mx-auto w-full relative">
      <div className="w-full flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest ${isHighRank ? 'bg-purple-600 text-white animate-pulse' : 'bg-[#2a2436] text-gray-400'}`}>
            {displayRank} RANK
          </div>
          {isHighRank && (
             <div className="px-3 py-1 rounded-full bg-red-600 text-white text-[10px] font-black uppercase tracking-widest shadow-lg shadow-red-600/30">
               EXPERT DIFFICULTY
             </div>
          )}
        </div>
        {!showQuitConfirm ? (
          <button 
            onClick={() => setShowQuitConfirm(true)} 
            className="text-gray-500 hover:text-red-400 text-[10px] font-black uppercase tracking-widest transition-colors flex items-center gap-1"
          >
            <X size={14} /> Quit Game
          </button>
        ) : (
          <div className="flex items-center gap-2 animate-in slide-in-from-right-4 duration-200">
            <span className="text-[10px] font-black text-red-500 uppercase tracking-tighter">Exit?</span>
            <button 
              onClick={() => {
                startNewGame();
                setShowQuitConfirm(false);
              }}
              className="text-red-500 hover:text-red-400 text-[10px] font-black uppercase underline underline-offset-4"
            >
              Confirm
            </button>
            <button 
              onClick={() => setShowQuitConfirm(false)}
              className="text-gray-500 hover:text-gray-300 text-[10px] font-black uppercase"
            >
              No
            </button>
          </div>
        )}
      </div>

      {/* Coin Rain Effect */}
      <AnimatePresence>
        {showCoinRain && Array.from({ length: 20 }).map((_, i) => (
          <motion.div
            key={`coin-${i}`}
            initial={{ opacity: 1, y: -50, x: (Math.random() - 0.5) * 500 }}
            animate={{ opacity: 0, y: window.innerHeight, rotate: Math.random() * 720 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 1.5 + Math.random(), ease: "easeIn" }}
            className="absolute top-0 pointer-events-none z-50 text-amber-500"
          >
            <Coins size={32} fill="currentColor" />
          </motion.div>
        ))}
      </AnimatePresence>

      <div className="w-full flex justify-between mb-8 text-gray-400 font-bold">
        <span>Question {currentIndex + 1} / {questions.length}</span>
        <span>Score: {score} {multiplier > 1 && <span className="text-amber-500">({multiplier}x)</span>}</span>
      </div>
      
      <h3 className="text-3xl font-bold mb-10 text-center leading-tight">
        {q.question}
        {hasStorm && <span className="block text-sm text-fuchsia-400 mt-2 italic flex">Hint Mode: Think carefully!</span>}
      </h3>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 w-full relative z-10">
        {q.options.map((opt: string, i: number) => {
          let bgColor = "bg-[#181520]";
          let borderColor = "border-[#2a2436]";
          if (isAnswering) {
            if (i === q.correctAnswerIndex) {
              bgColor = "bg-green-600/20";
              borderColor = "border-green-500";
            } else if (i === selectedAnswerIndex) {
              bgColor = "bg-red-600/20";
              borderColor = "border-red-500";
            }
          }
          return (
            <motion.button
              whileHover={!isAnswering ? { scale: 1.02 } : {}}
              whileTap={!isAnswering ? { scale: 0.98 } : {}}
              key={i}
              onClick={() => answerQuestion(i)}
              className={`${bgColor} border ${borderColor} text-left p-6 rounded-xl transition-all font-semibold`}
              disabled={isAnswering}
            >
              {opt}
            </motion.button>
          );
        })}
      </div>

      <AnimatePresence>
        {isAnswering && (
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className={`mt-10 text-2xl font-bold ${selectedAnswerIndex === q.correctAnswerIndex ? 'text-green-500' : 'text-red-500'}`}
          >
            {selectedAnswerIndex === q.correctAnswerIndex ? '✅ Correct! ' + (multiplier > 1 ? `(+${10 * multiplier} Pts)` : '') : '❌ Incorrect!'}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
};
