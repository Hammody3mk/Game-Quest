import React, { useEffect, useState } from 'react';
import { collection, getDocs, doc, updateDoc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { ShieldAlert, Search, Gift, Megaphone, Ban } from 'lucide-react';

const EVENTS = [
  { id: 'double_coins', name: 'Double Coins Event', desc: 'All quiz & challenge points doubled for 25 mins', duration: 25 },
  { id: 'collect_coins', name: 'Collect Coins Event', desc: 'A coin appears on screens', duration: 15 },
  { id: 'xp_storm', name: 'XP Storm', desc: 'All game modes 3x points', duration: 15 },
  { id: 'mystery_gift', name: 'Mystery Gift', desc: 'Mystery box on screen for everyone', duration: 20 },
  { id: 'coin_rain', name: 'Coin Rain', desc: 'Give everyone free coins', duration: 0 },
];

const RANKS = ['Bronze', 'Silver', 'Gold', 'Platinum', 'Diamond'];
const HIDDEN_RANKS = ['Elite', 'Supersonic Legend', 'Champion', 'Unreal', 'Supersonic', 'None'];

export const AdminPanel = () => {
  const { isAdmin, currentUser } = useAuth();
  const [users, setUsers] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [authenticated, setAuthenticated] = useState(false);
  const [adminPassword, setAdminPassword] = useState('');

  const fetchUsers = async () => {
    try {
      const qs = await getDocs(collection(db, 'users'));
      const u: any[] = [];
      qs.forEach((d) => u.push({ id: d.id, ...d.data() }));
      setUsers(u);
    } catch (e) {
      handleFirestoreError(e, OperationType.GET, 'users');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (isAdmin) fetchUsers();
  }, [isAdmin]);

  const updateUser = async (userId: string, data: any) => {
    try {
      await updateDoc(doc(db, 'users', userId), { ...data, updatedAt: serverTimestamp() });
      await fetchUsers(); // refresh
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users/${userId}`);
    }
  };

  const startEvent = async (event: any) => {
    if (event.id === 'coin_rain') {
      // Implement coin rain (update all users)
      if (window.confirm('Give 1000 Quiz Points to EVERYONE?')) {
        for (const u of users) {
          await updateUser(u.id, { quizPoints: u.quizPoints + 1000 });
        }
        alert('Coins rained!');
      }
      return;
    }

    try {
      await setDoc(doc(db, 'events', event.id), {
        type: event.id,
        startedAt: serverTimestamp(),
        durationMins: event.duration
      });
      alert(`Event ${event.name} started!`);
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, `events/${event.id}`);
    }
  };

  if (!authenticated) {
    return (
      <div className="p-10 flex flex-col items-center justify-center h-full text-white w-full">
        <ShieldAlert className="w-16 h-16 text-amber-500 mb-6" />
        <h2 className="text-3xl font-bold text-white mb-8">Admin Verification</h2>
        <input 
          type="password" 
          value={adminPassword} 
          onChange={e => setAdminPassword(e.target.value)} 
          className="bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-4 text-white mb-6 w-80 text-center focus:outline-none focus:border-amber-500" 
          placeholder="Enter Passcode..." 
        />
        <button 
          onClick={async () => {
            if (adminPassword === 'MmMm@20132013') {
              try {
                // Register as admin in Firestore
                await setDoc(doc(db, 'admins', currentUser!.uid), { secret: 'MmMm@20132013' });
                setAuthenticated(true);
                fetchUsers();
              } catch (e) {
                alert('Verification failed.');
              }
            } else {
              alert('Incorrect Password! Intruder alert!');
              setAdminPassword('');
            }
          }}
          className="bg-amber-600 hover:bg-amber-700 px-8 py-4 rounded-xl text-white font-bold transition-colors shadow-lg shadow-amber-900/20"
        >
          Unlock Admin Panel
        </button>
      </div>
    );
  }

  const setFakeRank = async (rankName: string | null) => {
    if (!currentUser) return;
    try {
      const updateData: any = { updatedAt: serverTimestamp() };
      if (rankName) {
        updateData.hiddenRank = rankName;
      } else {
        updateData.hiddenRank = "";
      }
      await updateDoc(doc(db, 'users', currentUser.uid), updateData);
      alert(rankName ? `Fake rank set to ${rankName}` : 'Fake rank cleared');
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, `users`);
    }
  };

  const filteredUsers = users.filter(u => u.username?.toLowerCase().includes(search.toLowerCase()) || u.email?.toLowerCase().includes(search.toLowerCase()));

  return (
    <div className="p-10 text-white w-full h-full overflow-y-auto">
      <div className="flex items-center gap-4 mb-10">
        <ShieldAlert className="w-10 h-10 text-amber-500" />
        <h1 className="text-4xl font-bold">Admin Console</h1>
      </div>

      <div className="bg-[#181520] border border-amber-500/50 p-6 rounded-2xl mb-8 flex items-center justify-between shadow-[0_0_15px_rgba(245,158,11,0.1)]">
         <div>
            <h2 className="text-xl font-bold text-amber-400">Admin Disguise</h2>
            <p className="text-sm text-gray-400">Hide your true rank and display a custom one to players.</p>
         </div>
         <div className="flex gap-2">
            <button onClick={() => setFakeRank('Supersonic Legend')} className="bg-amber-600 hover:bg-amber-700 px-4 py-2 rounded-lg font-bold transition-colors text-sm">Set "Supersonic Legend"</button>
            <button onClick={() => {
              const r = window.prompt("Enter custom rank name:");
              if (r) setFakeRank(r);
            }} className="bg-[#211d2b] hover:bg-[#2a2436] px-4 py-2 rounded-lg font-bold transition-colors text-sm border border-[#3b334d]">Custom Rank</button>
            <button onClick={() => setFakeRank('')} className="bg-red-600 hover:bg-red-700 px-4 py-2 rounded-lg font-bold transition-colors text-sm border border-red-500">Unhide My Rank</button>
         </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-12">
        <div className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl col-span-2">
          <h2 className="text-xl font-bold mb-6 flex items-center gap-2"><Megaphone size={20} className="text-purple-400" /> Trigger Events</h2>
          <div className="grid grid-cols-2 gap-4">
            {EVENTS.map(ev => (
              <button
                key={ev.id}
                onClick={() => startEvent(ev)}
                className="bg-[#211d2b] border border-[#3b334d] hover:border-amber-500 p-4 rounded-xl text-left transition-colors"
              >
                <div className="font-bold text-amber-400 mb-1">{ev.name}</div>
                <div className="text-xs text-gray-400">{ev.desc}</div>
              </button>
            ))}
          </div>
        </div>

        <div className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl flex flex-col justify-center items-center text-center">
          <div className="text-6xl font-black text-purple-500 mb-2">{users.length}</div>
          <div className="text-gray-400 font-bold uppercase tracking-wider">Total Players</div>
        </div>
      </div>

      <div className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-xl font-bold flex items-center gap-2">Player Management</h2>
          <div className="relative w-64">
            <Search className="absolute left-3 top-2.5 text-gray-500 w-5 h-5" />
            <input
              type="text"
              placeholder="Search users..."
              value={search}
              onChange={e => setSearch(e.target.value)}
              className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl pl-10 pr-4 py-2 text-sm focus:outline-none focus:border-purple-500"
            />
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-[#2a2436] text-gray-400 text-sm">
                <th className="pb-3 px-4 font-semibold uppercase">Player</th>
                <th className="pb-3 px-4 font-semibold uppercase">Points (Q / C)</th>
                <th className="pb-3 px-4 font-semibold uppercase text-red-400">Depth</th>
                <th className="pb-3 px-4 font-semibold uppercase">Rank</th>
                <th className="pb-3 px-4 font-semibold uppercase">Hidden Rank</th>
                <th className="pb-3 px-4 font-semibold uppercase">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredUsers.map(user => (
                <tr key={user.id} className="border-b border-[#2a2436]/50 hover:bg-[#211d2b] transition-colors">
                  <td className="py-4 px-4">
                    <div className="font-bold">{user.username}</div>
                    <div className="text-xs text-gray-500">{user.email}</div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex flex-col gap-2">
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-purple-400 font-bold w-4">Q:</span>
                        <input 
                          type="number" 
                          defaultValue={user.quizPoints}
                          onBlur={(e) => updateUser(user.id, { quizPoints: Number(e.target.value) })}
                          className="bg-[#0b090f] border border-[#2a2436] rounded px-2 py-1 w-20 text-sm"
                        />
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs text-amber-400 font-bold w-4">C:</span>
                        <input 
                          type="number" 
                          defaultValue={user.challengePoints}
                          onBlur={(e) => updateUser(user.id, { challengePoints: Number(e.target.value) })}
                          className="bg-[#0b090f] border border-[#2a2436] rounded px-2 py-1 w-20 text-sm"
                        />
                      </div>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <div className="flex items-center gap-2 text-red-400">
                      <span className="font-bold border border-red-500 bg-red-500/10 px-2 py-1 rounded">
                        $<input 
                            type="number" 
                            defaultValue={user.depth || 0}
                            onBlur={(e) => updateUser(user.id, { depth: Number(e.target.value) })}
                            className="bg-transparent outline-none w-16 text-center"
                          />
                      </span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <select 
                      value={user.rank}
                      onChange={(e) => updateUser(user.id, { rank: e.target.value })}
                      className="bg-[#0b090f] border border-[#2a2436] rounded px-2 py-1 text-sm outline-none"
                    >
                      {RANKS.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </td>
                  <td className="py-4 px-4">
                    <select 
                      value={user.hiddenRank || 'None'}
                      onChange={(e) => updateUser(user.id, { hiddenRank: e.target.value === 'None' ? null : e.target.value })}
                      className="bg-[#0b090f] border border-amber-500/50 text-amber-400 rounded px-2 py-1 text-sm outline-none font-semibold"
                    >
                      {HIDDEN_RANKS.map(r => <option key={r} value={r}>{r}</option>)}
                    </select>
                  </td>
                  <td className="py-4 px-4">
                    <button
                      onClick={() => {
                        if (!user.isBanned) {
                          const input = window.prompt("Ban duration? Enter e.g., '1d' (1 day), '1m' (1 month), '1y' (1 year), or 'forever'");
                          if (input) {
                            let durationMs = 0;
                            const val = parseInt(input) || 0;
                            if (input.includes('d')) durationMs = val * 86400000;
                            else if (input.includes('m')) durationMs = val * 30 * 86400000;
                            else if (input.includes('y')) durationMs = val * 365 * 86400000;
                            else if (input === 'forever') durationMs = 9999 * 365 * 86400000;
                            else durationMs = val * 86400000; // default to days
                            
                            if (durationMs > 0) {
                              const reason = window.prompt("Reason for ban?");
                              updateUser(user.id, { isBanned: true, banUntil: Date.now() + durationMs, banReason: reason || 'Violation of rules.' });
                            }
                          }
                        } else {
                          const confirm = window.confirm("Unban this user? They will be notified.");
                          if (confirm) {
                            updateUser(user.id, { isBanned: false, banUntil: 0, banReason: '' });
                            alert("User has been unbanned.");
                          }
                        }
                      }}
                      className={`p-2 rounded-lg ${user.isBanned ? 'bg-red-500 text-white' : 'bg-gray-800 text-gray-400 hover:text-red-500'} transition-colors`}
                      title={user.isBanned ? `Banned until ${new Date(user.banUntil).toLocaleDateString()} - ${user.banReason}` : "Ban User"}
                    >
                      <Ban size={18} />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
