import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Users, Search, Swords, Check, X, ShieldAlert, Sparkles, Trophy, MessageSquare, Send, RotateCcw } from 'lucide-react';
import { collection, query, where, getDocs, setDoc, doc, serverTimestamp, updateDoc, getDoc, onSnapshot, or, addDoc } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { generateMultiplayerQuestions } from '../lib/gemini';

export const Multiplayer = () => {
  const { userProfile, currentUser, reloadProfile } = useAuth();
  const [activeTab, setActiveTab] = useState<'qr'|'search'>('qr');
  const [searchQuery, setSearchQuery] = useState('');
  const [searchedUsers, setSearchedUsers] = useState<any[]>([]);
  const [wager, setWager] = useState(1);
  const [wagerType, setWagerType] = useState('all');
  const [subject, setSubject] = useState('math');
  const [friendsDetails, setFriendsDetails] = useState<any[]>([]);
  const [loadingFriends, setLoadingFriends] = useState(false);

  const [matches, setMatches] = useState<any[]>([]);
  const [activeMatch, setActiveMatch] = useState<any | null>(null);
  const [arenaMatch, setArenaMatch] = useState<any | null>(null);
  const [generating, setGenerating] = useState(false);
  const [wrongIndex, setWrongIndex] = useState<number | null>(null);
  
  const [messages, setMessages] = useState<any[]>([]);
  const [chatFriend, setChatFriend] = useState<any | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const chatEndRef = useRef<HTMLDivElement>(null);

  const [currentTab, setCurrentTab] = useState<'lobby' | 'friends' | 'search' | 'messages'>('lobby');
  const [friendRequests, setFriendRequests] = useState<any[]>([]);
  const [gameMode, setGameMode] = useState('10_questions');
  
  const [timeLeft, setTimeLeft] = useState(60);
  const [showForfeitConfirm, setShowForfeitConfirm] = useState(false);
  const [showResetConfirm, setShowResetConfirm] = useState(false);

  const prevRequestsRef = useRef<Set<string>>(new Set());
  const prevMatchesRef = useRef<Set<string>>(new Set());

  // These depend on arenaMatch state but must be called unconditionally at top level
  // We can calculate derived state here, or wait until arenaMatch is truthy inside the hooks.
  const isCreator = currentUser?.uid === arenaMatch?.creatorId;
  const myProgress = isCreator ? arenaMatch?.creatorProgress : arenaMatch?.opponentProgress;
  const myScore = isCreator ? arenaMatch?.creatorScore : arenaMatch?.opponentScore;
  const theirProgress = isCreator ? arenaMatch?.opponentProgress : arenaMatch?.creatorProgress;
  const theirScore = isCreator ? arenaMatch?.opponentScore : arenaMatch?.creatorScore;
  const myFinished = isCreator ? arenaMatch?.creatorFinished : arenaMatch?.opponentFinished;
  const theirFinished = isCreator ? arenaMatch?.opponentFinished : arenaMatch?.creatorFinished;
  const requiredAmount = arenaMatch?.amount || 10;
  const currentQuestion = arenaMatch?.questions?.[myProgress];

  const forceFinish = async () => {
      if (!arenaMatch || myFinished) return;
      try {
        const updates: any = { updatedAt: serverTimestamp() };
        updates[isCreator ? 'creatorFinished' : 'opponentFinished'] = true;
        await updateDoc(doc(db, 'multiplayer', arenaMatch.id), updates);
      } catch(e) {}
  };

  useEffect(() => {
     if (!arenaMatch || arenaMatch.gameMode !== '1_minute' || myFinished || arenaMatch.status === 'completed') return;
     const timerId = setInterval(() => {
         setTimeLeft(prev => {
             if (prev <= 1) {
                 clearInterval(timerId);
                 forceFinish();
                 return 0;
             }
             return prev - 1;
         });
     }, 1000);
     return () => clearInterval(timerId);
  }, [arenaMatch?.gameMode, myFinished, arenaMatch?.status, arenaMatch?.id]);

  useEffect(() => {
     if (!arenaMatch || arenaMatch.status === 'completed' || !isCreator) return;
     
     // If both finished but status is playing, creator finalizes it to avoid race condition
     if (arenaMatch.creatorFinished && arenaMatch.opponentFinished) {
         const finalMyScore = arenaMatch.creatorScore || 0;
         const finalTheirScore = arenaMatch.opponentScore || 0;
         let winnerId = 'draw';
         if (finalMyScore > finalTheirScore) winnerId = currentUser?.uid;
         else if (finalTheirScore > finalMyScore) winnerId = arenaMatch.opponentId;

         const winField = arenaMatch.wagerType === 'challenge' ? 'challengePoints' : 'quizPoints'; 
         
         const finalize = async () => {
            try {
              await updateDoc(doc(db, 'multiplayer', arenaMatch.id), {
                status: 'completed',
                winnerId,
                updatedAt: serverTimestamp()
              });
              if (winnerId !== 'draw') {
                 const loserId = winnerId === currentUser?.uid ? arenaMatch.opponentId : currentUser?.uid;
                 const winnerDoc = await getDoc(doc(db, 'users', winnerId));
                 const loserDoc = await getDoc(doc(db, 'users', loserId));
                 if (winnerDoc.exists() && loserDoc.exists()) {
                    const wPts = (winnerDoc.data()[winField] || 0) + arenaMatch.wager;
                    const lPts = Math.max(0, (loserDoc.data()[winField] || 0) - arenaMatch.wager);
                    await updateDoc(doc(db, 'users', winnerId), { [winField]: wPts });
                    await updateDoc(doc(db, 'users', loserId), { [winField]: lPts });
                 }
              }
            } catch(e) {}
         };
         finalize();
     }
  }, [arenaMatch]);

  useEffect(() => {
    if (!currentUser) return;
    const qMsgs = query(
      collection(db, 'messages'),
      or(
        where('senderId', '==', currentUser.uid),
        where('receiverId', '==', currentUser.uid)
      )
    );
    const unsubMsgs = onSnapshot(qMsgs, (snapshot) => {
       const msgs: any[] = [];
       snapshot.forEach(d => msgs.push({id: d.id, ...d.data()}));
       msgs.sort((a,b) => (a.createdAt?.toMillis() || 0) - (b.createdAt?.toMillis() || 0));
       setMessages(msgs);
       setTimeout(() => {
          chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
       }, 100);
    });

    const qReqs = query(
      collection(db, 'friendRequests'),
      or(
        where('senderId', '==', currentUser.uid),
        where('receiverId', '==', currentUser.uid)
      )
    );
    const unsubReqs = onSnapshot(qReqs, async (snapshot) => {
       const reqs: any[] = [];
       snapshot.forEach(d => reqs.push({id: d.id, ...d.data()}));
       // Fetch usernames
       for (const r of reqs) {
          if (!r.senderName) {
            try {
              const d = await getDoc(doc(db, 'users', r.senderId));
              if (d.exists()) r.senderName = d.data().username;
            } catch(e){}
          }
       }
       setFriendRequests(reqs);
    });

    const q = query(
      collection(db, 'multiplayer'),
      or(
        where('creatorId', '==', currentUser.uid),
        where('opponentId', '==', currentUser.uid)
      )
    );
    const unsub = onSnapshot(q, async (snapshot) => {
      const allMatches: any[] = [];
      snapshot.forEach(d => allMatches.push({ id: d.id, ...d.data() }));
      allMatches.sort((a, b) => (b.updatedAt?.toMillis() || 0) - (a.updatedAt?.toMillis() || 0));
      
      // Get opponent names if missing
      for (const m of allMatches) {
        if (!m.opponentName || !m.creatorName) {
           try {
             if (!m.creatorName) {
                const cDoc = await getDoc(doc(db, 'users', m.creatorId));
                if (cDoc.exists()) m.creatorName = cDoc.data().username;
             }
             if (!m.opponentName) {
                const oDoc = await getDoc(doc(db, 'users', m.opponentId));
                if (oDoc.exists()) m.opponentName = oDoc.data().username;
             }
           } catch(e){}
        }
      }

      setMatches(allMatches);

      // Current playing match detection
      const playing = allMatches.find(m => m.status === 'playing');
      if (playing) {
        setArenaMatch(playing);
      } else {
        setArenaMatch(null);
      }

      // Check for incoming pending challenge notification
      if (localStorage.getItem('gq_notif_multi') !== 'false' && 'Notification' in window) {
         const newPendingObj = allMatches.find(m => m.status === 'pending' && m.opponentId === currentUser.uid && m.createdAt?.toMillis() > Date.now() - 5000);
         if (newPendingObj && Notification.permission === 'granted') {
            new Notification("New Challenge!", { body: `You have been challenged to a ${newPendingObj.subject} match by ${newPendingObj.creatorName || 'a player'}!` });
         }
      }
    }, (error) => {
      console.error(error);
    });
    return () => {
      unsub();
      unsubMsgs();
      unsubReqs();
    };
  }, [currentUser]);

  useEffect(() => {
    const fetchFriends = async () => {
      if (!userProfile?.friends || userProfile.friends.length === 0) {
        setFriendsDetails([]);
        return;
      }
      setLoadingFriends(true);
      try {
        const friendDocs = await Promise.all(
          userProfile.friends.map(uid => getDoc(doc(db, 'users', uid)))
        );
        const details = friendDocs
          .filter(d => d.exists())
          .map(d => ({ id: d.id, ...d.data() }));
        setFriendsDetails(details);
      } catch (e) {
        console.error("Error fetching friends:", e);
      } finally {
        setLoadingFriends(false);
      }
    };
    fetchFriends();
  }, [userProfile?.friends]);

  const handleSearch = async (overrideQuery?: string | React.MouseEvent | React.SyntheticEvent) => {
    const queryStr = typeof overrideQuery === 'string' ? overrideQuery : searchQuery;
    const term = queryStr.trim();
    if (!term) return;
    try {
      const q = query(
        collection(db, 'users'), 
        where('username', '>=', term),
        where('username', '<=', term + '\uf8ff')
      );
      const snap = await getDocs(q);
      const res: any[] = [];
      snap.forEach(d => {
        if (d.id !== currentUser?.uid) res.push({ id: d.id, ...d.data() });
      });
      setSearchedUsers(res);
    } catch (error) {
      handleFirestoreError(error, OperationType.GET, 'users');
    }
  };

  const addFriend = async (friendId: string) => {
    if (!currentUser || !userProfile) return;
    try {
      await addDoc(collection(db, 'friendRequests'), {
        senderId: currentUser.uid,
        receiverId: friendId,
        status: 'pending',
        createdAt: serverTimestamp()
      });
      alert('Friend request sent!');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'friendRequests');
    }
  };

  const acceptFriend = async (req: any) => {
    if (!currentUser || !userProfile) return;
    try {
      // 1. Add senderId to my friends
      const myFriends = userProfile.friends ? [...userProfile.friends] : [];
      if (!myFriends.includes(req.senderId)) myFriends.push(req.senderId);
      await updateDoc(doc(db, 'users', currentUser.uid), { friends: myFriends, updatedAt: serverTimestamp() });
      
      // Update request to accepted
      await updateDoc(doc(db, 'friendRequests', req.id), { status: 'accepted', updatedAt: serverTimestamp() });
      await reloadProfile();
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'friendRequests');
    }
  };

  const declineFriend = async (reqId: string) => {
    try {
      await updateDoc(doc(db, 'friendRequests', reqId), { status: 'declined', updatedAt: serverTimestamp() });
    } catch (error) {
      handleFirestoreError(error, OperationType.UPDATE, 'friendRequests');
    }
  };

  // Whenever we load friend requests, notify if there's a new incoming request
  useEffect(() => {
    if (!currentUser) return;
    const incomingPending = friendRequests.filter(r => r.receiverId === currentUser.uid && r.status === 'pending');
    
    // Check if we have seen these requests using a ref
    const newRequests = incomingPending.filter(r => !prevRequestsRef.current?.has(r.id));
    if (newRequests.length > 0) {
       if ('Notification' in window && Notification.permission === 'granted' && localStorage.getItem('gq_notif_friends') !== 'false') {
          newRequests.forEach(req => {
             new Notification('New Friend Request!', { body: `${req.senderName || 'A player'} wants to be your friend!` });
          });
       }
    }
    
    const nextSet = new Set<string>();
    incomingPending.forEach(r => nextSet.add(r.id));
    prevRequestsRef.current = nextSet;
  }, [friendRequests, currentUser]);

  // Whenever we load matches, notify if there's a new incoming match
  useEffect(() => {
     if (!currentUser) return;
     const incomingMatches = matches.filter(m => m.opponentId === currentUser.uid && m.status === 'pending');
     
     const newMatches = incomingMatches.filter(m => !prevMatchesRef.current.has(m.id));
     if (newMatches.length > 0) {
        if ('Notification' in window && Notification.permission === 'granted' && localStorage.getItem('gq_notif_friends') !== 'false') {
           newMatches.forEach(m => {
              new Notification('New Challenge!', { body: `${m.creatorName || 'A player'} challenged you in ${m.subject}!` });
           });
        }
     }
     
     const nextSet = new Set<string>();
     incomingMatches.forEach(m => nextSet.add(m.id));
     prevMatchesRef.current = nextSet;
  }, [matches, currentUser]);

  // Whenever we load friend requests and there's an 'accepted' one where we are the sender,
  // we add the receiver to our friend list and delete/update the request.
  useEffect(() => {
    if (!currentUser || !userProfile) return;
    const updateMyFriends = async () => {
       const acceptedMyRequests = friendRequests.filter(r => r.senderId === currentUser.uid && r.status === 'accepted');
       if (acceptedMyRequests.length > 0) {
          let updated = false;
          const myFriends = userProfile.friends ? [...userProfile.friends] : [];
          for (const req of acceptedMyRequests) {
             if (!myFriends.includes(req.receiverId)) {
                myFriends.push(req.receiverId);
                updated = true;
             }
             // we can't delete it easily unless we wrote rules for it, let's just mark it 'completed' so it doesn't process again
             try {
                await updateDoc(doc(db, 'friendRequests', req.id), { status: 'completed', updatedAt: serverTimestamp() });
             } catch(e){}
          }
          if (updated) {
             await updateDoc(doc(db, 'users', currentUser.uid), { friends: myFriends, updatedAt: serverTimestamp() });
             await reloadProfile();
          }
       }
    };
    updateMyFriends();
  }, [friendRequests, currentUser, userProfile]);

  const challengeUser = async (opponentId: string) => {
    if (!currentUser || !userProfile) return;
    
    let finalWager = wager;
    if (wagerType === 'all') {
      finalWager = Math.max(userProfile.quizPoints + userProfile.challengePoints, 0);
      if (finalWager === 0) finalWager = 100;
    }
    
    // Allow debt actually if they want to explicitly wager, but let's keep the block for standard wager.
    // wait, the prompt says "If you do not have enough, it will put you in a debt."
    // So I will remove the check. Let them go in debt!
    
    let amount = 10;
    if (gameMode === '20_questions') amount = 20;
    if (gameMode === '30_questions') amount = 30;
    if (gameMode === '50_questions' || gameMode === '1_minute') amount = 50;

    try {
      const matchId = Date.now().toString();
      await setDoc(doc(db, 'multiplayer', matchId), {
        creatorId: currentUser.uid,
        opponentId,
        wager: finalWager,
        isAllIn: wagerType === 'all',
        wagerType: wagerType,
        subject: subject,
        gameMode: gameMode || '10_questions',
        amount: amount,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      alert('Challenge sent!');
    } catch (e) {
      handleFirestoreError(e, OperationType.CREATE, 'multiplayer');
    }
  };

  const acceptMatch = async (match: any) => {
    setGenerating(true);
    try {
      const questions = await generateMultiplayerQuestions(match.subject || 'math', match.amount || 10);
      await updateDoc(doc(db, 'multiplayer', match.id), {
        status: 'playing',
        questions,
        creatorProgress: 0,
        opponentProgress: 0,
        creatorScore: 0,
        opponentScore: 0,
        creatorFinished: false,
        opponentFinished: false,
        updatedAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'multiplayer');
    } finally {
      setGenerating(false);
    }
  };

  const declineMatch = async (matchId: string) => {
    try {
      await updateDoc(doc(db, 'multiplayer', matchId), {
        status: 'declined',
        updatedAt: serverTimestamp()
      });
    } catch (e) {
      handleFirestoreError(e, OperationType.UPDATE, 'multiplayer');
    }
  };

  const sendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim() || !currentUser || !chatFriend) return;
    try {
      await addDoc(collection(db, 'messages'), {
        senderId: currentUser.uid,
        receiverId: chatFriend.id,
        text: newMessage.trim(),
        read: false,
        createdAt: serverTimestamp()
      });
      setNewMessage('');
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'messages');
    }
  };

  // MULTIPLAYER ARENA VIEW
  if (arenaMatch) {
     const answerQuestion = async (idx: number) => {
       if (!currentQuestion || myFinished) return;
       const correct = idx === currentQuestion.correctAnswerIndex;
       
       const nextProgress = (myProgress || 0) + 1;
       const nextScore = (myScore || 0) + (correct ? 1 : 0);
       const isFinishedNow = nextProgress >= requiredAmount || (arenaMatch.gameMode === '1_minute' && timeLeft <= 0);

       try {
         const updates: any = {
           updatedAt: serverTimestamp()
         };
         
         updates[isCreator ? 'creatorProgress' : 'opponentProgress'] = nextProgress;
         updates[isCreator ? 'creatorScore' : 'opponentScore'] = nextScore;
         updates[isCreator ? 'creatorFinished' : 'opponentFinished'] = isFinishedNow;

         await updateDoc(doc(db, 'multiplayer', arenaMatch.id), updates);
       } catch (e) {
         handleFirestoreError(e, OperationType.UPDATE, 'multiplayer');
       }
     };

     return (
       <div className="p-10 flex flex-col h-full max-w-4xl mx-auto w-full text-white">
         <div className="flex items-center justify-between gap-4 mb-10 w-full">
           <div className="flex items-center gap-4">
             <div className="bg-red-600/20 p-3 rounded-xl animate-pulse">
               <Swords className="w-8 h-8 text-red-500" />
             </div>
             <h2 className="text-3xl font-bold">Arena: {arenaMatch.subject}</h2>
           </div>
           {!showForfeitConfirm ? (
             <button 
               onClick={() => setShowForfeitConfirm(true)}
               className="bg-red-900/20 hover:bg-red-900/40 border border-red-500/30 text-red-500 px-4 py-2 rounded-xl text-sm font-bold transition-all active:scale-95 flex items-center gap-2"
             >
               <X size={16} /> Forfeit & Exit
             </button>
           ) : (
             <div className="flex items-center gap-2 animate-in zoom-in-95 duration-200">
               <span className="text-xs font-bold text-red-400 uppercase tracking-widest mr-2">Confirm Forfeit?</span>
               <button 
                 onClick={() => {
                   setArenaMatch(null);
                   setCurrentTab('lobby');
                   setShowForfeitConfirm(false);
                 }}
                 className="bg-red-600 hover:bg-red-700 text-white px-3 py-1.5 rounded-lg text-xs font-bold shadow-lg"
               >
                 Yes, Exit
               </button>
               <button 
                 onClick={() => setShowForfeitConfirm(false)}
                 className="bg-gray-700 hover:bg-gray-600 text-white px-3 py-1.5 rounded-lg text-xs font-bold"
               >
                 Cancel
               </button>
             </div>
           )}
         </div>

         <div className="bg-[#181520] border border-[#2a2436] p-8 rounded-2xl flex flex-col items-center">
            <div className="w-full flex justify-between mb-8">
               <div className="text-center">
                 <div className="font-bold text-xl text-emerald-400">YOU</div>
                 <div className="text-sm text-gray-400 mb-1">Score: {myScore || 0}</div>
                 <div className="text-3xl font-black">{Math.min(myProgress || 0, requiredAmount)}/{requiredAmount}</div>
               </div>

               {arenaMatch.gameMode === '1_minute' && (
                 <div className="text-center flex flex-col justify-center">
                    <div className="text-sm font-bold text-yellow-500 uppercase tracking-widest mb-1">Time Left</div>
                    <div className={`text-4xl font-black ${timeLeft <= 10 ? 'text-red-500 animate-pulse' : 'text-yellow-400'}`}>00:{timeLeft.toString().padStart(2, '0')}</div>
                 </div>
               )}

               <div className="text-center opacity-50">
                 <div className="font-bold text-xl text-red-400">OPPONENT</div>
                 <div className="text-sm text-gray-400 mb-1">Score: {theirScore || 0}</div>
                 <div className="text-3xl font-black">{Math.min(theirProgress || 0, requiredAmount)}/{requiredAmount}</div>
               </div>
            </div>

            {arenaMatch.status === 'completed' ? (
              <div className="text-center py-10 w-full animate-in fade-in zoom-in-95 duration-500">
                {arenaMatch.winnerId === 'draw' ? (
                  <>
                    <h3 className="text-4xl font-bold mb-2 text-gray-400">DRAW!</h3>
                    <p className="text-gray-500 mb-8">You both scored {myScore} / 10. No points transferred.</p>
                  </>
                ) : (
                  <>
                    <Trophy size={64} className={`mx-auto mb-4 ${arenaMatch.winnerId === currentUser?.uid ? 'text-yellow-400' : 'text-red-500'}`} />
                    <h3 className="text-4xl font-black mb-2 tracking-tight">
                      {arenaMatch.winnerId === currentUser?.uid ? 'YOU WON!' : 'YOU LOST!'}
                    </h3>
                    <p className="text-gray-400 mb-8 text-lg">
                      {arenaMatch.winnerId === currentUser?.uid ? `You snagged the ${arenaMatch.wager} pts pot!` : `Opponent took the ${arenaMatch.wager} pts pot.`}
                    </p>
                  </>
                )}
                
                <div className="bg-[#211d2b] border border-[#3b334d] rounded-xl p-6 mb-8 max-w-sm mx-auto">
                   <div className="flex justify-between items-center mb-4 border-b border-[#3b334d] pb-4">
                     <span className="font-bold text-gray-400">Final Scores</span>
                   </div>
                   <div className="flex justify-between items-center mb-2">
                     <span>You</span>
                     <span className="font-bold text-emerald-400">{myScore} / {requiredAmount}</span>
                   </div>
                   <div className="flex justify-between items-center">
                     <span>Opponent</span>
                     <span className="font-bold text-red-400">{theirScore} / {requiredAmount}</span>
                   </div>
                </div>

                <button onClick={() => setArenaMatch(null)} className="w-full max-w-sm bg-purple-600 hover:bg-purple-700 px-6 py-4 rounded-xl font-bold text-lg shadow-lg shadow-purple-900/50 transition-all">
                   Leave Arena
                </button>
              </div>
            ) : myFinished ? (
              <div className="text-center py-16">
                 <div className="inline-block p-4 bg-emerald-900/30 rounded-full mb-6">
                   <Check size={48} className="text-emerald-500" />
                 </div>
                 <h3 className="text-2xl font-bold mb-2">Waiting for opponent...</h3>
                 <p className="text-gray-400">You scored {myScore} / {requiredAmount}. We'll reveal the winner once they finish.</p>
              </div>
            ) : currentQuestion ? (
              <div className="w-full max-w-2xl">
                <div className="mb-8">
                  <div className="text-sm font-bold text-purple-400 mb-2 uppercase tracking-wider">Question {(myProgress || 0) + 1} of {requiredAmount}</div>
                  <h3 className="text-2xl font-bold text-white leading-tight">{currentQuestion.question}</h3>
                </div>
                <div className="grid grid-cols-1 gap-4">
                  {currentQuestion.options.map((opt: string, idx: number) => (
                    <button 
                      key={idx}
                      onClick={() => answerQuestion(idx)}
                      className="w-full text-left bg-[#211d2b] hover:bg-purple-900/50 border border-[#3b334d] hover:border-purple-500/50 p-5 rounded-xl font-medium transition-all group"
                    >
                      <span className="inline-block w-8 h-8 rounded-lg bg-[#181520] group-hover:bg-purple-600 text-center leading-8 mr-4 transition-colors">
                        {['A', 'B', 'C', 'D'][idx]}
                      </span>
                      {opt}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              <div className="text-center py-10">Generating questions or error occurred...</div>
            )}
         </div>
       </div>
     );
  }
  const incomingMatches = matches.filter(m => m.opponentId === currentUser?.uid && m.status === 'pending');
  if (currentTab === 'lobby') {
    return (
      <div className="p-10 flex flex-col h-full max-w-5xl mx-auto w-full text-white animate-in fade-in zoom-in-95 duration-300">
        <div className="flex items-center justify-between gap-4 mb-2">
          <div className="flex items-center gap-4">
            <div className="bg-emerald-600/20 p-3 rounded-xl">
               <Swords className="w-8 h-8 text-emerald-500" />
            </div>
            <h2 className="text-4xl font-black tracking-tight">Multiplayer Lobby</h2>
          </div>
          {!showResetConfirm ? (
            <button 
              onClick={() => setShowResetConfirm(true)}
              className="text-gray-500 hover:text-red-400 text-xs font-bold uppercase tracking-widest transition-colors flex items-center gap-1"
            >
              <RotateCcw size={14} /> Clear State
            </button>
          ) : (
            <div className="flex items-center gap-3 animate-in fade-in slide-in-from-right-4 duration-200">
              <span className="text-[10px] font-black text-red-400 uppercase tracking-tighter">Reset Interface?</span>
              <button 
                onClick={() => {
                  setArenaMatch(null);
                  setCurrentTab('lobby');
                  setGenerating(false);
                  setWrongIndex(null);
                  setShowResetConfirm(false);
                }}
                className="text-red-500 hover:text-red-400 text-xs font-bold uppercase underline underline-offset-4"
              >
                Reset
              </button>
              <button 
                onClick={() => setShowResetConfirm(false)}
                className="text-gray-500 hover:text-gray-300 text-xs font-bold uppercase"
              >
                Cancel
              </button>
            </div>
          )}
        </div>
        <p className="text-gray-400 mb-10 text-lg">Challenge players, add friends, and dominate the arena.</p>
        
        {incomingMatches.length > 0 && (
          <div className="mb-8 bg-purple-900/40 border border-purple-500/50 p-6 rounded-2xl cursor-pointer hover:bg-purple-900/60 transition-colors" onClick={() => setCurrentTab('search')}>
            <h3 className="font-bold text-xl text-purple-300 flex items-center gap-2"><Sparkles className="animate-pulse" /> Incoming Challenges! ({incomingMatches.length})</h3>
            <p className="text-sm text-gray-400 mt-1">Tap to view your pending matches in Search & Challenge.</p>
          </div>
        )}

        {friendRequests.filter(r => r.receiverId === currentUser?.uid && r.status === 'pending').length > 0 && (
          <div className="mb-8 bg-emerald-900/40 border border-emerald-500/50 p-6 rounded-2xl cursor-pointer hover:bg-emerald-900/60 transition-colors" onClick={() => setCurrentTab('friends')}>
             <h3 className="font-bold text-xl text-emerald-400 flex items-center gap-2"><Users className="animate-bounce" /> New Friend Requests!</h3>
             <p className="text-sm text-gray-400 mt-1">Tap to view and accept them in Friends & Social.</p>
          </div>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <button 
            onClick={() => setCurrentTab('friends')}
            className="bg-[#181520] hover:bg-[#211d2b] border border-[#2a2436] hover:border-emerald-500/50 p-10 rounded-3xl flex flex-col items-center justify-center transition-all group shadow-xl"
          >
            <Users size={64} className="text-emerald-500 mb-6 group-hover:scale-110 transition-transform duration-300" />
            <div className="text-2xl font-bold mb-2">Friends</div>
            <p className="text-gray-400 text-sm text-center">View friends, accept requests, and build your circle.</p>
          </button>
          
          <button 
            onClick={() => setCurrentTab('search')}
            className="bg-[#181520] hover:bg-[#211d2b] border border-[#2a2436] hover:border-purple-500/50 p-10 rounded-3xl flex flex-col items-center justify-center transition-all group shadow-xl"
          >
            <Search size={64} className="text-purple-500 mb-6 group-hover:scale-110 transition-transform duration-300" />
            <div className="text-2xl font-bold mb-2">Search & Challenge</div>
            <p className="text-gray-400 text-sm text-center">Find players, set your stakes, and start matches.</p>
          </button>
          
          <button 
            onClick={() => setCurrentTab('messages')}
            className="bg-[#181520] hover:bg-[#211d2b] border border-[#2a2436] hover:border-blue-500/50 p-10 rounded-3xl flex flex-col items-center justify-center transition-all group shadow-xl"
          >
            <MessageSquare size={64} className="text-blue-500 mb-6 group-hover:scale-110 transition-transform duration-300" />
            <div className="text-2xl font-bold mb-2">Messages</div>
            <p className="text-gray-400 text-sm text-center">Chat with your friends and talk trash.</p>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="p-4 md:p-10 flex flex-col h-full max-w-5xl mx-auto w-full text-white animate-in slide-in-from-right-4 duration-300">
      <div className="flex items-center gap-4 mb-8">
        <button 
          onClick={() => setCurrentTab('lobby')}
          className="bg-[#181520] hover:bg-[#2a2436] border border-[#2a2436] p-4 rounded-xl transition-colors shadow-lg active:scale-95"
          title="Back to Lobby Dashboard"
        >
          <X className="text-gray-400" size={24} />
        </button>
        <h2 className="text-3xl font-bold capitalize">
           {currentTab === 'friends' ? 'Friends & Social' : currentTab === 'search' ? 'Search & Challenge' : 'Messages'}
        </h2>
      </div>

      {currentTab === 'search' && (
        <div className="flex flex-col gap-8 w-full max-w-2xl mx-auto">
          {incomingMatches.length > 0 && (
            <div className="bg-purple-900/40 border border-purple-500/50 p-6 rounded-2xl shadow-xl">
              <h3 className="font-bold text-xl mb-4 text-purple-300 flex items-center gap-2"><Sparkles className="animate-pulse" /> Incoming Challenges!</h3>
              <div className="space-y-4">
                {incomingMatches.map(m => (
                  <div key={m.id} className="bg-[#181520] border border-purple-500/30 p-4 rounded-xl flex flex-col md:flex-row items-center justify-between">
                     <div>
                       <div className="font-bold">{m.creatorName || 'A Player'} challenged you!</div>
                       <div className="text-sm text-gray-400 mt-1">
                         Mode: {m.gameMode === '1_minute' ? '1 Min Timer' : m.gameMode?.replace('_', ' ')} | Subject: {m.subject}
                       </div>
                       <div className="text-sm font-bold text-yellow-500 mt-1">
                         Wager: {m.wagerType === 'all' ? '💀 ALL IN (Loss = Debt)' : `${m.wager} pts (${m.wagerType})`}
                       </div>
                     </div>
                     <div className="flex gap-2 mt-4 md:mt-0">
                        <button onClick={() => acceptMatch(m)} disabled={generating} className="bg-emerald-600 hover:bg-emerald-700 px-6 py-2 rounded-xl font-bold flex items-center gap-2 shadow-lg active:scale-95 transition-all">
                          {generating ? 'Joining...' : 'Accept'} <Check size={18} />
                        </button>
                        <button onClick={() => declineMatch(m.id)} className="bg-[#211d2b] hover:bg-[#3b334d] px-4 py-2 rounded-xl shadow-lg active:scale-95 transition-all">
                          <X size={18} />
                        </button>
                     </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          <div className="bg-[#181520] border border-[#2a2436] p-8 rounded-2xl flex flex-col shadow-xl">
            <h3 className="text-xl font-bold mb-6">Find & Challenge</h3>
            <div className="flex gap-2 mb-8">
              <input type="text" placeholder="Enter exact username..." value={searchQuery} onChange={e => setSearchQuery(e.target.value)} className="flex-grow bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500" />
              <button onClick={handleSearch} className="bg-purple-600 hover:bg-purple-700 p-3 rounded-xl transition-colors shadow-lg active:scale-95"><Search className="text-white" /></button>
            </div>

            <div className="mb-6 border-t border-[#2a2436] pt-6 grid grid-cols-2 gap-4">
              <div>
                <label className="block text-gray-400 text-xs font-bold mb-2 uppercase tracking-widest">Subject</label>
                <select value={subject} onChange={(e) => setSubject(e.target.value)} className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                  <option value="general">General Knowledge</option>
                  <option value="math">Math</option>
                  <option value="science">Science</option>
                </select>
              </div>
              <div>
                <label className="block text-gray-400 text-xs font-bold mb-2 uppercase tracking-widest">Game Mode</label>
                <select value={gameMode} onChange={(e) => setGameMode(e.target.value)} className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                  <option value="10_questions">10 Questions</option>
                  <option value="20_questions">20 Questions</option>
                  <option value="30_questions">30 Questions</option>
                  <option value="50_questions">50 Questions</option>
                  <option value="1_minute">1 Min Timer</option>
                </select>
              </div>
              <div className="col-span-2">
                <label className="block text-gray-400 text-xs font-bold mb-2 uppercase tracking-widest">Points Source</label>
                <select value={wagerType} onChange={(e) => setWagerType(e.target.value)} className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500">
                  <option value="quiz">Quiz Points</option>
                  <option value="challenge">Challenge Points</option>
                  <option value="all">🏆 All Available Points (All In)</option>
                </select>
              </div>
            </div>
            
            <div className="mb-8">
              <label className="block text-gray-400 text-xs font-bold mb-2 uppercase tracking-widest">
                {wagerType === 'all' ? 'Wager Status' : 'Wager Amount (1-1000)'}
              </label>
              {wagerType === 'all' ? (
                <div className="w-full bg-red-900/20 border-2 border-red-500/50 rounded-xl px-4 py-3 text-red-500 font-black text-center animate-pulse tracking-widest italic shadow-[0_0_15px_rgba(239,68,68,0.2)]">
                  💀 ALL IN (Take debt if lost) 💀
                </div>
              ) : (
                <input type="number" min="1" max="1000" value={wager} onChange={(e) => setWager(Number(e.target.value))} className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-all"/>
              )}
            </div>

            <div className="flex-grow mb-8 overflow-y-auto max-h-[300px] border-b border-[#2a2436] pb-4">
              {searchedUsers.length > 0 ? (
                searchedUsers.map(u => {
                  const isFriend = userProfile?.friends?.includes(u.id);
                  return (
                    <div key={u.id} className="bg-[#211d2b] border border-[#3b334d] p-4 rounded-xl flex flex-col md:flex-row items-start md:items-center justify-between mb-2">
                       <div className="mb-2 md:mb-0">
                         <div className="font-bold text-lg">{u.username}</div>
                         <div className="text-xs text-emerald-400 font-bold uppercase tracking-wider">{u.rank || 'Bronze'} | {(u.quizPoints||0)+(u.challengePoints||0)} PTS</div>
                       </div>
                       <div className="flex items-center gap-2">
                         {!isFriend && (
                           <button onClick={() => addFriend(u.id)} className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-700 px-4 py-2 rounded-xl text-sm font-bold shadow-lg active:scale-95 transition-all">
                             <Users size={16} /> Add Friend
                           </button>
                         )}
                         <button onClick={() => challengeUser(u.id)} className="flex items-center gap-2 bg-purple-600 hover:bg-purple-700 px-4 py-2 rounded-xl text-sm font-bold shadow-lg active:scale-95 transition-all">
                           <Swords size={16} /> Challenge
                         </button>
                       </div>
                    </div>
                  );
                })
              ) : (
                <div className="text-center text-gray-500 py-10 italic">Your search format is exact... Enter precise username hook line and sink them!</div>
              )}
            </div>
            
            <div>
               <h4 className="font-bold mb-4 text-emerald-500 text-sm uppercase tracking-widest">Recent Matches</h4>
               <div className="space-y-2 max-h-[200px] overflow-y-auto pr-2">
                 {matches.filter(m => m.status !== 'playing' && !(m.opponentId === currentUser?.uid && m.status === 'pending')).map(m => (
                   <div key={m.id} className="bg-[#110e16] border border-[#3b334d] p-3 rounded-xl flex items-center justify-between text-sm">
                      <div>
                        <span className="font-bold">{m.creatorId === currentUser?.uid ? 'You' : (m.creatorName || 'A Player')}</span> vs <span className="font-bold">{m.opponentId === currentUser?.uid ? 'You' : (m.opponentName || 'A Player')}</span>
                        <div className="text-xs text-gray-500">{m.subject} | {m.wager} pts {m.wagerType === 'all' && '💀'}</div>
                      </div>
                      <div className={`px-3 py-1 rounded-lg text-xs font-bold uppercase ${m.status === 'pending' ? 'bg-yellow-500/20 text-yellow-500' : m.status === 'declined' ? 'bg-red-500/20 text-red-500' : m.winnerId === currentUser?.uid ? 'bg-green-500/20 text-green-500' : 'bg-gray-500/20 text-gray-400'}`}>
                        {m.status === 'pending' ? 'Pending' : m.status === 'declined' ? 'Declined' : m.winnerId === currentUser?.uid ? 'Won' : 'Lost'}
                      </div>
                   </div>
                 ))}
                 {matches.filter(m => m.status !== 'playing' && !(m.opponentId === currentUser?.uid && m.status === 'pending')).length === 0 && (
                   <div className="text-xs text-gray-600 italic">No recent matches...</div>
                 )}
               </div>
            </div>
          </div>
        </div>
      )}

      {currentTab === 'friends' && (
        <div className="w-full max-w-2xl mx-auto flex flex-col gap-8">
           {friendRequests.filter(r => r.receiverId === currentUser?.uid && r.status === 'pending').length > 0 && (
              <div className="bg-[#181520] border border-[#2a2436] p-6 rounded-2xl shadow-xl">
                 <h3 className="text-lg font-bold mb-4 text-emerald-400 flex items-center gap-2">
                    <Users size={20} /> Pending Friend Requests
                 </h3>
                 <div className="space-y-3">
                   {friendRequests.filter(r => r.receiverId === currentUser?.uid && r.status === 'pending').map(req => (
                     <div key={req.id} className="bg-[#211d2b] border border-[#3b334d] p-4 rounded-xl flex items-center justify-between">
                        <div className="font-bold text-lg">{req.senderName || 'A player'} wants to be friends!</div>
                        <div className="flex gap-2">
                           <button onClick={() => acceptFriend(req)} className="bg-emerald-600 hover:bg-emerald-700 px-4 py-2 rounded-xl font-bold shadow-lg active:scale-95 transition-all text-sm">Accept</button>
                           <button onClick={() => declineFriend(req.id)} className="bg-[#3b334d] hover:bg-[#4a4060] px-4 py-2 rounded-xl shadow-lg active:scale-95 transition-all text-sm">Decline</button>
                        </div>
                     </div>
                   ))}
                 </div>
              </div>
           )}

           <div className="bg-[#181520] border border-[#2a2436] p-8 rounded-2xl shadow-xl">
             <h3 className="text-xl font-bold mb-2">My Friends</h3>
             <p className="text-gray-400 text-sm mb-6">You have {friendsDetails.length} friend{friendsDetails.length !== 1 && 's'}.</p>
             <div className="grid grid-cols-1 gap-3">
               {loadingFriends ? (
                  <div className="text-gray-500 animate-pulse text-center p-8">Loading friends...</div>
               ) : friendsDetails.length > 0 ? (
                  friendsDetails.map(f => (
                     <div key={f.id} className="bg-[#211d2b] border border-[#3b334d] p-4 rounded-xl flex items-center justify-between transition-colors hover:border-emerald-500/50">
                         <div className="flex items-center gap-4">
                           <div className="w-12 h-12 rounded-full bg-gradient-to-tr from-purple-600 to-emerald-600 flex items-center justify-center font-black text-lg">
                             {f.username?.[0]?.toUpperCase()}
                           </div>
                           <div>
                             <div className="font-bold text-lg capitalize">{f.username}</div>
                             <div className="text-xs text-gray-500 font-bold uppercase tracking-wider">{f.rank || 'Bronze'} | {(f.quizPoints||0)+(f.challengePoints||0)} PTS</div>
                           </div>
                         </div>
                         <div className="flex gap-2">
                           <button onClick={() => { setChatFriend(f); setCurrentTab('messages'); }} title="Message" className="px-4 py-3 bg-blue-500/10 text-blue-500 hover:bg-blue-500 hover:text-white rounded-xl transition-all shadow-lg active:scale-95 text-sm font-bold flex items-center gap-2">
                              <MessageSquare size={16} /> Message
                           </button>
                           <button onClick={() => { setCurrentTab('search'); setTimeout(() => setSearchQuery(f.username), 100); }} title="Challenge" className="px-4 py-3 bg-purple-500/10 text-purple-500 hover:bg-purple-500 hover:text-white rounded-xl transition-all shadow-lg active:scale-95 text-sm font-bold flex items-center gap-2">
                              <Swords size={16} /> Challenge
                           </button>
                         </div>
                     </div>
                  ))
               ) : (
                  <div className="text-gray-500 text-center p-8 border border-dashed border-[#3b334d] rounded-xl italic">
                     You have no friends yet. Go to Search & Challenge to find players!
                  </div>
               )}
             </div>
           </div>
        </div>
      )}

      {currentTab === 'messages' && (
        <div className="w-full max-w-5xl mx-auto flex gap-6 h-[600px] bg-[#181520] border border-[#2a2436] rounded-3xl p-4 shadow-2xl">
           <div className="w-1/3 bg-[#211d2b] rounded-2xl overflow-hidden flex flex-col border border-[#3b334d]">
              <div className="p-5 border-b border-[#3b334d] font-bold text-lg flex items-center gap-2"><Users size={20} className="text-blue-500" /> Contacts</div>
              <div className="overflow-y-auto flex-grow p-3 space-y-2">
                 {friendsDetails.map(f => (
                    <button 
                      key={f.id} 
                      onClick={() => setChatFriend(f)}
                      className={`w-full text-left p-4 rounded-xl flex items-center gap-4 transition-all ${chatFriend?.id === f.id ? 'bg-[#3b334d] shadow-lg scale-100' : 'hover:bg-[#2a2436] active:scale-95'}`}
                    >
                      <div className="w-10 h-10 rounded-full bg-gradient-to-tr from-purple-600 to-blue-600 flex items-center justify-center font-bold text-sm shadow-md">{f.username?.[0]?.toUpperCase()}</div>
                      <div>
                         <div className="font-bold truncate text-sm">{f.username}</div>
                         <div className="text-xs text-blue-400">Tap to chat</div>
                      </div>
                    </button>
                 ))}
                 {friendsDetails.length === 0 && <div className="text-gray-500 p-8 text-center text-sm italic border border-dashed border-[#3b334d] rounded-xl m-2">Add friends first to start messaging.</div>}
              </div>
           </div>
           
           <div className="w-2/3 bg-[#211d2b] border border-[#3b334d] rounded-2xl flex flex-col overflow-hidden shadow-inner relative">
              {chatFriend ? (
                 <>
                   <div className="p-5 border-b border-[#3b334d] font-bold text-lg bg-[#2a2436] flex items-center gap-3 shadow-md z-10">
                     <div className="w-8 h-8 rounded-full bg-purple-600 flex items-center justify-center font-bold text-xs">{chatFriend.username?.[0]?.toUpperCase()}</div>
                     {chatFriend.username}
                   </div>
                   <div className="flex-grow overflow-y-auto p-6 flex flex-col gap-4">
                      {messages.filter(m => m.senderId === chatFriend.id || m.receiverId === chatFriend.id).map(m => {
                         const isMe = m.senderId === currentUser?.uid;
                         return (
                           <div key={m.id} className={`flex ${isMe ? 'justify-end' : 'justify-start'}`}>
                              <div className={`p-4 rounded-2xl max-w-[80%] text-sm shadow-md ${isMe ? 'bg-blue-600 text-white rounded-br-sm' : 'bg-[#3b334d] text-white rounded-bl-sm'}`}>
                                 {m.text}
                              </div>
                           </div>
                         );
                      })}
                      {messages.filter(m => m.senderId === chatFriend.id || m.receiverId === chatFriend.id).length === 0 && (
                         <div className="text-center text-gray-400 mt-20 italic">Start the conversation with {chatFriend.username}!</div>
                      )}
                      <div ref={chatEndRef} />
                   </div>
                   <form onSubmit={sendMessage} className="p-4 border-t border-[#3b334d] bg-[#2a2436] flex gap-3 z-10">
                     <input type="text" value={newMessage} onChange={e => setNewMessage(e.target.value)} placeholder={`Message ${chatFriend.username}...`} className="flex-grow bg-[#110e16] border border-[#3b334d] rounded-xl px-5 py-3 focus:outline-none focus:border-blue-500 shadow-inner" />
                     <button disabled={!newMessage.trim()} type="submit" className="bg-blue-600 hover:bg-blue-700 disabled:opacity-50 px-6 rounded-xl font-bold shadow-lg active:scale-95 transition-all text-white flex items-center gap-2">
                       <Send size={18} />
                     </button>
                   </form>
                 </>
              ) : (
                 <div className="flex-grow flex flex-col items-center justify-center text-gray-500">
                    <MessageSquare size={64} className="mb-4 opacity-50" />
                    <div className="text-lg italic text-gray-400">Select a contact to start messaging.</div>
                 </div>
              )}
           </div>
        </div>
      )}
    </div>
  );
};
