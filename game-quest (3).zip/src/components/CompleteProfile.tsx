import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { doc, setDoc, serverTimestamp } from 'firebase/firestore';
import { db, handleFirestoreError, OperationType } from '../lib/firebase';
import { Brain, LogOut } from 'lucide-react';

export const CompleteProfile = () => {
  const { currentUser, reloadProfile, logout } = useAuth();
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser) return;
    if (!username.trim()) {
      setError('Username is required');
      return;
    }
    setLoading(true);
    setError('');

    try {
      await setDoc(doc(db, 'users', currentUser.uid), {
        email: currentUser.email,
        username: username.trim(),
        quizPoints: 0,
        challengePoints: 0,
        rank: 'Bronze',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });
      await reloadProfile();
    } catch (err: any) {
      setError(err.message || 'Failed to setup profile. Make sure you follow the rules.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0b090f] flex items-center justify-center p-4">
      <div className="bg-[#181520] border border-[#2a2436] p-8 rounded-2xl w-full max-w-md shadow-2xl">
        <div className="flex flex-col items-center mb-8">
          <div className="bg-purple-600 p-4 rounded-2xl mb-4">
            <Brain className="text-white w-10 h-10" />
          </div>
          <h1 className="text-3xl font-extrabold text-white tracking-tight">Complete Profile</h1>
          <p className="text-gray-400 mt-2 text-sm text-center">
            Choose an epic username before continuing your adventure.
          </p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/50 text-red-500 p-3 rounded-lg mb-4 text-sm">
            {error}
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-gray-400 text-xs font-semibold mb-1 uppercase tracking-wide">Username</label>
            <input
              type="text"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              className="w-full bg-[#0b090f] border border-[#2a2436] rounded-xl px-4 py-3 text-white focus:outline-none focus:border-purple-500 transition-colors"
              placeholder="EpicGamer123"
              required
            />
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-purple-600 hover:bg-purple-700 text-white font-bold py-3 px-4 rounded-xl transition-colors disabled:opacity-50 mt-4"
          >
            {loading ? 'Saving...' : 'Finish Setup'}
          </button>
        </form>

        <button onClick={logout} className="mt-6 flex w-full justify-center items-center gap-2 text-gray-400 hover:text-white transition-colors">
          <LogOut size={16} /> Sign Out
        </button>
      </div>
    </div>
  );
};
